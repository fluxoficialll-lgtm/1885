
import pg from 'pg';
import cassandra from 'cassandra-driver';
import Redis from 'ioredis';
import crypto from 'crypto';

const { Pool } = pg;

// --- CONFIGURAÇÃO DAS CONEXÕES (WIRES) ---

// 1. PostgreSQL (Dados Relacionais: Users, Groups, Finance)
// Ajustado para usar o nome do serviço 'postgres' definido no docker-compose ou localhost como fallback
const PG_HOST = process.env.DB_HOST || (process.env.DOCKER_ENV ? 'postgres' : 'localhost');
const PG_CONN_STRING = process.env.DATABASE_URL || `postgresql://flux_admin:flux_password_secure@${PG_HOST}:5432/flux_core`;

const pgPool = new Pool({
    connectionString: PG_CONN_STRING,
    max: 20, // Limite de conexões por worker
    idleTimeoutMillis: 30000
});

// 2. ScyllaDB (High Velocity Data: Posts, Feed, Analytics)
const SCYLLA_HOST = process.env.SCYLLA_HOST || (process.env.DOCKER_ENV ? 'scylla' : 'localhost');

const scyllaClient = new cassandra.Client({
    contactPoints: [SCYLLA_HOST],
    localDataCenter: 'datacenter1',
    keyspace: 'system', // Conecta no system primeiro para criar a keyspace se não existir
    pooling: {
        coreConnectionsPerHost: {
            [cassandra.types.distance.local]: 2,
            [cassandra.types.distance.remote]: 1
        }
    }
});

// 3. Redis (Sessões, Cache, Real-time Pub/Sub)
const REDIS_HOST = process.env.REDIS_HOST || (process.env.DOCKER_ENV ? 'redis' : 'localhost');
const REDIS_URL = process.env.REDIS_URL || `redis://${REDIS_HOST}:6379`;

const redis = new Redis(REDIS_URL, {
    retryStrategy: (times) => Math.min(times * 50, 2000)
});

// --- INICIALIZAÇÃO DE SCHEMAS ---

const initDatabases = async () => {
    console.log(`🔌 [BACKEND] Conectando à infraestrutura... (PG: ${PG_HOST}, Scylla: ${SCYLLA_HOST})`);

    try {
        // A) Inicializar Postgres Tables
        // Tenta conectar com retry, pois o container do banco pode demorar a subir
        let retries = 5;
        while (retries > 0) {
            try {
                await pgPool.query('SELECT 1');
                break;
            } catch (e) {
                console.log(`⏳ Aguardando PostgreSQL... (${retries})`);
                await new Promise(res => setTimeout(res, 2000));
                retries--;
            }
        }

        await pgPool.query(`
            CREATE TABLE IF NOT EXISTS users (
                email VARCHAR(255) PRIMARY KEY,
                password_hash TEXT NOT NULL,
                profile JSONB,
                created_at TIMESTAMP DEFAULT NOW(),
                full_data JSONB -- Armazena o objeto completo para compatibilidade rápida
            );
        `);
        
        await pgPool.query(`
            CREATE TABLE IF NOT EXISTS groups (
                id VARCHAR(50) PRIMARY KEY,
                creator_email VARCHAR(255),
                data JSONB
            );
        `);

        console.log("✅ [POSTGRES] Schemas Ready.");

        // B) Inicializar ScyllaDB Keyspace e Tables
        // Retry para Scylla também
        retries = 10;
        while (retries > 0) {
            try {
                await scyllaClient.connect();
                break;
            } catch (e) {
                console.log(`⏳ Aguardando ScyllaDB... (${retries})`);
                await new Promise(res => setTimeout(res, 3000));
                retries--;
            }
        }
        
        // Criar Keyspace
        await scyllaClient.execute(`
            CREATE KEYSPACE IF NOT EXISTS flux_data 
            WITH replication = {'class': 'SimpleStrategy', 'replication_factor': 1};
        `);
        
        // Mudar para a keyspace correta
        await scyllaClient.execute('USE flux_data');

        // Tabela de Posts (Otimizada para Time-Series)
        await scyllaClient.execute(`
            CREATE TABLE IF NOT EXISTS posts (
                id text,
                timestamp bigint,
                data text, -- JSON stringificado para flexibilidade
                PRIMARY KEY (id)
            );
        `);
        
        // Índice secundário para ordenar (em prod usaríamos Materialized Views ou Clustering Keys adequadas)
        await scyllaClient.execute(`
            CREATE INDEX IF NOT EXISTS ON posts (timestamp);
        `);

        console.log("✅ [SCYLLA] Schemas Ready.");
        console.log("✅ [REDIS] Connected.");

    } catch (error) {
        console.error("❌ [DB INIT ERROR] Falha ao conectar na infraestrutura.", error.message);
        console.log("⚠️ Servidor rodando, mas endpoints de banco podem falhar se os containers não estiverem ativos.");
    }
};

export const dbManager = {
    init: initDatabases,
    state: { mode: 'ENTERPRISE_SCALABLE' },

    admin: {
        async getStats() {
            try {
                const userCount = await pgPool.query('SELECT COUNT(*) FROM users');
                // Nota: Count em Scylla/Cassandra é custoso, usamos estimativa ou removemos em alta carga
                const postCount = await scyllaClient.execute('SELECT count(*) FROM posts'); 
                return {
                    users: parseInt(userCount.rows[0].count),
                    posts_approx: postCount.rows[0].count.toString(),
                    redis_status: redis.status,
                    architecture: 'Microservices-Ready (PG + Scylla + Redis)'
                };
            } catch (e) {
                return { error: "Database stats unavailable", details: e.message };
            }
        }
    },

    // --- AUTH LAYER (PostgreSQL + Redis) ---
    auth: {
        async register(email, passwordHash, profileData) {
            const client = await pgPool.connect();
            try {
                // Verificar existência
                const check = await client.query('SELECT email FROM users WHERE email = $1', [email]);
                if (check.rows.length > 0) throw new Error("Email already registered");

                const fullUser = {
                    email,
                    isVerified: true,
                    isProfileCompleted: true,
                    profile: profileData,
                    ...profileData
                };

                await client.query(
                    'INSERT INTO users (email, password_hash, profile, full_data) VALUES ($1, $2, $3, $4)',
                    [email, passwordHash, profileData, fullUser]
                );
                return fullUser;
            } finally {
                client.release();
            }
        },

        async login(email, passwordHash) {
            const res = await pgPool.query('SELECT * FROM users WHERE email = $1', [email]);
            const userRow = res.rows[0];
            
            if (!userRow) throw new Error("User not found");
            if (userRow.password_hash !== passwordHash) throw new Error("Invalid credentials");
            
            const userData = userRow.full_data || { email: userRow.email, profile: userRow.profile };

            // Redis Session (Expirando em 24h)
            const token = crypto.randomBytes(32).toString('hex');
            await redis.set(`sess:${token}`, JSON.stringify(userData), 'EX', 86400);
            
            return { user: userData, token };
        },

        async getUser(email) {
            const res = await pgPool.query('SELECT full_data FROM users WHERE email = $1', [email]);
            return res.rows[0]?.full_data || null;
        },

        async searchUsers(query) {
            if (!query) return [];
            // Busca simples no Postgres (Em prod, usaríamos Elasticsearch)
            const term = `%${query}%`;
            const res = await pgPool.query(
                `SELECT full_data FROM users WHERE email ILIKE $1 OR full_data->'profile'->>'name' ILIKE $1 LIMIT 20`, 
                [term]
            );
            return res.rows.map(r => {
                const u = r.full_data;
                delete u.password; // Sanitize
                return u;
            });
        }
    },

    // --- POSTS LAYER (ScyllaDB - Alta Performance) ---
    posts: {
        async list(limit = 20, cursor = Date.now()) {
            // CQL Query
            const query = 'SELECT data FROM posts WHERE timestamp < ? ALLOW FILTERING';
            const result = await scyllaClient.execute(query, [cursor], { prepare: true, fetchSize: limit });
            
            // Ordenar em memória se o Scylla não retornar ordenado
            const posts = result.rows.map(row => JSON.parse(row.data));
            return posts.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
        },

        async create(post) {
            const newPost = { ...post, id: crypto.randomUUID(), timestamp: Date.now() };
            
            await scyllaClient.execute(
                'INSERT INTO posts (id, timestamp, data) VALUES (?, ?, ?)',
                [newPost.id, newPost.timestamp, JSON.stringify(newPost)],
                { prepare: true }
            );
            
            return newPost;
        },

        async toggleLike(postId, userEmail) {
            const result = await scyllaClient.execute('SELECT data FROM posts WHERE id = ?', [postId], { prepare: true });
            if (result.rowLength === 0) return null;

            const post = JSON.parse(result.rows[0].data);
            
            if (!post.likedBy) post.likedBy = [];
            const index = post.likedBy.indexOf(userEmail);
            
            if (index === -1) {
                post.likedBy.push(userEmail);
                post.likes = (post.likes || 0) + 1;
                post.liked = true; 
            } else {
                post.likedBy.splice(index, 1);
                post.likes = Math.max(0, (post.likes || 0) - 1);
                post.liked = false;
            }

            await scyllaClient.execute(
                'UPDATE posts SET data = ? WHERE id = ?',
                [JSON.stringify(post), postId],
                { prepare: true }
            );

            return post;
        },

        async addComment(postId, comment) {
            const result = await scyllaClient.execute('SELECT data FROM posts WHERE id = ?', [postId], { prepare: true });
            if (result.rowLength === 0) return null;

            const post = JSON.parse(result.rows[0].data);
            if (!post.commentsList) post.commentsList = [];
            
            post.commentsList.unshift(comment);
            post.comments = post.commentsList.length;

            await scyllaClient.execute(
                'UPDATE posts SET data = ? WHERE id = ?',
                [JSON.stringify(post), postId],
                { prepare: true }
            );
            return comment;
        },

        async delete(id) {
            await scyllaClient.execute('DELETE FROM posts WHERE id = ?', [id], { prepare: true });
            return true;
        }
    },

    // --- GROUPS LAYER (PostgreSQL - Integridade Referencial) ---
    groups: {
        async list() {
            const res = await pgPool.query('SELECT data FROM groups ORDER BY id DESC LIMIT 50');
            return res.rows.map(r => r.data);
        },
        async create(group) {
            const groupData = { ...group };
            await pgPool.query(
                'INSERT INTO groups (id, creator_email, data) VALUES ($1, $2, $3)',
                [group.id, group.creatorEmail, groupData]
            );
            return true;
        },
        async delete(id) {
            await pgPool.query('DELETE FROM groups WHERE id = $1', [id]);
            return true;
        }
    },

    users: {
        async update(email, updates) {
            const current = await this.auth.getUser(email);
            if (!current) return null;

            const updatedUser = { ...current, ...updates };
            if (updates.profile) {
                updatedUser.profile = { ...current.profile, ...updates.profile };
            }

            await pgPool.query(
                'UPDATE users SET full_data = $1, profile = $2 WHERE email = $3',
                [updatedUser, updatedUser.profile, email]
            );
            
            return updatedUser;
        }
    }
};
