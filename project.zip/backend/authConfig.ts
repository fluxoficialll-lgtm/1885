
/**
 * Configurações de Autenticação (Backend)
 * 
 * As chaves fornecidas foram configuradas como padrão para garantir o funcionamento imediato.
 * Em um ambiente de produção rigoroso, recomenda-se mover o Client Secret para variáveis de ambiente (.env).
 */

const isProduction = process.env.NODE_ENV === 'production';

// Validação relaxada pois temos fallbacks hardcoded agora
if (isProduction && !process.env.GOOGLE_CLIENT_ID && !process.env.GOOGLE_CLIENT_SECRET) {
    console.warn("⚠️  Aviso: Credenciais do Google não encontradas nas variáveis de ambiente. Usando chaves padrão configuradas.");
}

export const googleAuthConfig = {
    // Chave Pública
    clientId: process.env.GOOGLE_CLIENT_ID || "302886927628-1ubai85cjaabnud3j18b62fmjvk7m91q.apps.googleusercontent.com",
    
    // Chave Privada (MANTER APENAS NO BACKEND)
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || "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",
    
    redirectUri: process.env.APP_URL ? `${process.env.APP_URL}/auth/callback` : "http://localhost:3000/auth/callback"
};
