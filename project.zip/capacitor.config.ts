
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fluxplatform.app',
  appName: 'Flux Platform',
  webDir: 'dist',
  server: {
    // Removemos 'androidScheme' para usar o padrão file:// ou http://localhost 
    // dependendo da versão, mas 'https' é seguro. 
    // O importante é NÃO ter 'url' apontando para IP externo.
    androidScheme: 'https'
  },
  plugins: {
    // Configurações futuras de plugins nativos virão aqui
  }
};

export default config;
