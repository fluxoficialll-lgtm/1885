
// Serviço de Criptografia usando Web Crypto API (AES-GCM).
// Padrões OWASP 2023: AES-GCM 256 bits + PBKDF2 com 600.000 iterações para chave.

const ALGORITHM = 'AES-GCM';
const KEY_USAGE: KeyUsage[] = ['encrypt', 'decrypt'];
const PBKDF2_ITERATIONS = 600000; // OWASP recommendation for HMAC-SHA256

// Salt fixo para dados locais (Em backend real, usar salt aleatório por usuário)
// Nota: Em um ambiente cliente-side puro, esconder chaves é impossível. 
// Esta implementação protege contra leitura casual do LocalStorage (XSS básico/Acesso físico).
const LOCAL_SALT = "FLUX_PLATFORM_SECURE_SALT_V3"; 
const APP_SECRET = "flux_secure_app_key_change_this_in_prod"; 

// Gera uma chave a partir do segredo
const deriveKey = async (password: string): Promise<CryptoKey> => {
    const enc = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
        "raw",
        enc.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );

    return window.crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: enc.encode(LOCAL_SALT),
            iterations: PBKDF2_ITERATIONS,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: ALGORITHM, length: 256 },
        false, 
        KEY_USAGE
    );
};

// Helpers de conversão
const buff_to_base64 = (buff: Uint8Array): string => btoa(String.fromCharCode.apply(null, Array.from(buff)));
const base64_to_buf = (b64: string): Uint8Array => Uint8Array.from(atob(b64), c => c.charCodeAt(0));

export const cryptoService = {
  
  // Hash unidirecional para senhas (Client-side apenas para o fluxo Mock)
  hashPassword: async (password: string): Promise<string> => {
    const msgBuffer = new TextEncoder().encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  /**
   * Criptografa dados usando AES-GCM.
   * Formato de Saída: "IV_BASE64:CIPHERTEXT_BASE64"
   */
  encryptData: async (data: string): Promise<string> => {
    try {
        const key = await deriveKey(APP_SECRET);
        const encodedData = new TextEncoder().encode(data);
        
        // Gera um IV aleatório de 12 bytes (96 bits) para cada encriptação
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        
        const encrypted = await window.crypto.subtle.encrypt(
            { name: ALGORITHM, iv: iv },
            key,
            encodedData
        );

        const ivHex = buff_to_base64(iv);
        const encryptedHex = buff_to_base64(new Uint8Array(encrypted));

        return `${ivHex}:${encryptedHex}`;
    } catch (e) {
        console.error("Crypto Error:", e);
        throw new Error("Falha crítica na segurança dos dados.");
    }
  },

  /**
   * Descriptografa dados no formato "IV:CIPHERTEXT".
   */
  decryptData: async (encryptedString: string): Promise<string> => {
    try {
        if (!encryptedString || !encryptedString.includes(':')) return "";

        const parts = encryptedString.split(':');
        if (parts.length !== 2) throw new Error("Formato de dados corrompido");

        const iv = base64_to_buf(parts[0]);
        const ciphertext = base64_to_buf(parts[1]);
        const key = await deriveKey(APP_SECRET);

        const decrypted = await window.crypto.subtle.decrypt(
            { name: ALGORITHM, iv: iv },
            key,
            ciphertext
        );

        return new TextDecoder().decode(decrypted);
    } catch (e) {
        console.error("Decrypt Error: Falha de integridade ou chave incorreta.", e);
        // Retorna string vazia para evitar crash da UI, mas loga o erro de segurança
        return "";
    }
  }
};
