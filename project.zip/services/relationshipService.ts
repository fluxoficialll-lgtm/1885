
import { Relationship, User } from '../types';
import { authService } from './authService';
import { notificationService } from './notificationService';
import { db } from '@/database';

// Helper to simulate DB delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const relationshipService = {
  getRelationships: (): Relationship[] => {
    return db.relationships.getAll();
  },

  followUser: async (targetUsername: string): Promise<'following' | 'requested'> => {
    // Retry Logic for Stability
    await delay(300);
    
    const currentUserEmail = authService.getCurrentUserEmail();
    
    if (!currentUserEmail) {
        throw new Error("Usuário não logado");
    }

    let currentUser = authService.getCurrentUser();
    
    if (!currentUser) {
        let retries = 5; 
        while (!currentUser && retries > 0) {
            await delay(300);
            currentUser = authService.getCurrentUser();
            retries--;
        }
    }
    
    if (!currentUser) {
        const dbUser = db.users.get(currentUserEmail);
        if (dbUser) {
            currentUser = dbUser;
        } else {
            currentUser = {
                email: currentUserEmail,
                isVerified: true,
                isProfileCompleted: true,
                profile: {
                    name: currentUserEmail.split('@')[0],
                    nickname: 'Usuário',
                    isPrivate: false,
                    photoUrl: undefined
                }
            } as User;
        }
    }

    const targetClean = targetUsername.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    const existing = rels.find(r => r.followerEmail === currentUserEmail && r.followingUsername === targetClean);
    if (existing) return existing.status === 'accepted' ? 'following' : 'requested';

    const allUsers = db.users.getAll();
    const targetUser = Object.values(allUsers).find(u => u.profile?.name === targetClean);
    
    let status: 'accepted' | 'pending' = 'accepted';
    
    if (targetUser && targetUser.profile?.isPrivate) {
        status = 'pending';
    }

    const newRel: Relationship = {
        followerEmail: currentUserEmail,
        followingUsername: targetClean,
        status: status
    };

    db.relationships.add(newRel);

    if (targetUser) {
        notificationService.addNotification({
            type: status === 'accepted' ? 'follow' : 'pending',
            subtype: status === 'pending' ? 'friend' : undefined,
            username: currentUser.profile?.name || 'Alguém',
            avatar: currentUser.profile?.photoUrl || '',
            text: status === 'accepted' ? 'começou a te seguir.' : 'solicitou para te seguir.',
            recipientEmail: targetUser.email,
            isFollowing: true
        });
    }
    
    return status === 'accepted' ? 'following' : 'requested';
  },

  unfollowUser: async (targetUsername: string) => {
    await delay(200);
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return;
    
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    db.relationships.remove(currentUserEmail, targetClean);
  },

  acceptFollowRequest: async (followerHandle: string) => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser || !currentUser.profile?.name) return;

      const myUsername = currentUser.profile.name.toLowerCase();
      const followerClean = followerHandle.replace('@', '').toLowerCase();
      const followerUser = authService.getUserByHandle(followerClean);
      
      if (!followerUser) return;

      const followerEmail = followerUser.email;
      const allRels = db.relationships.getAll();
      const rel = allRels.find(r => 
          r.followerEmail === followerEmail && 
          r.followingUsername === myUsername
      );

      if (rel) {
          rel.status = 'accepted';
          db.relationships.add(rel);

          notificationService.addNotification({
              type: 'follow', 
              username: currentUser.profile.name,
              avatar: currentUser.profile.photoUrl || '',
              text: 'aceitou sua solicitação. Agora você pode ver o perfil.',
              recipientEmail: followerEmail,
              isFollowing: true
          });
      }
  },

  rejectFollowRequest: async (followerHandle: string) => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser || !currentUser.profile?.name) return;

      const myUsername = currentUser.profile.name.toLowerCase();
      const followerClean = followerHandle.replace('@', '').toLowerCase();
      const followerUser = authService.getUserByHandle(followerClean);
      
      if (!followerUser) return;
      
      const followerEmail = followerUser.email;
      db.relationships.remove(followerUser.email, myUsername);

      notificationService.addNotification({
          type: 'follow',
          username: currentUser.profile.name,
          avatar: currentUser.profile.photoUrl || '',
          text: 'não aceitou sua solicitação de seguir.',
          recipientEmail: followerEmail,
          isFollowing: false
      });
  },

  isFollowing: (targetUsername: string): 'none' | 'following' | 'requested' => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return 'none';
    
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    
    const rel = rels.find(r => r.followerEmail === currentUserEmail && r.followingUsername === targetClean);
    
    if (!rel) return 'none';
    return rel.status === 'accepted' ? 'following' : 'requested';
  },

  getFollowers: (username: string): { name: string; username: string; avatar?: string }[] => {
    const cleanUsername = username.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    const allUsers = db.users.getAll();

    const followerEmails = rels
        .filter(r => r.followingUsername === cleanUsername && r.status === 'accepted')
        .map(r => r.followerEmail);

    const followers = followerEmails.map(email => {
        const user = allUsers[email];
        if (user && user.profile) {
            return {
                name: user.profile.nickname || user.profile.name,
                username: user.profile.name,
                avatar: user.profile.photoUrl
            };
        }
        return { name: 'Usuário', username: 'user', avatar: undefined };
    });

    return followers;
  },

  getFollowing: (email: string): { name: string; username: string; avatar?: string }[] => {
    const rels = db.relationships.getAll();
    const allUsers = db.users.getAll();

    const followingUsernames = rels
        .filter(r => r.followerEmail === email && r.status === 'accepted')
        .map(r => r.followingUsername);

    const following: { name: string; username: string; avatar?: string }[] = [];
    const usersArray = Object.values(allUsers);

    followingUsernames.forEach(targetUsername => {
        const user = usersArray.find(u => u.profile?.name === targetUsername);
        if (user && user.profile) {
            following.push({
                name: user.profile.nickname || user.profile.name,
                username: user.profile.name,
                avatar: user.profile.photoUrl
            });
        } else {
            following.push({
                name: targetUsername,
                username: targetUsername,
                avatar: undefined
            });
        }
    });

    return following;
  },

  getMutualFriends: async (): Promise<{id: number | string, name: string, username: string, avatar: string}[]> => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return [];

    const users = db.users.getAll();
    const myProfile = users[currentUserEmail];
    const myUsername = myProfile?.profile?.name?.toLowerCase();

    if (!myUsername) return [];

    const rels = db.relationships.getAll();
    const iFollowUsernames = rels
        .filter(r => r.followerEmail === currentUserEmail && r.status === 'accepted')
        .map(r => r.followingUsername);

    const usersFollowingMeEmails = rels
        .filter(r => r.followingUsername === myUsername && r.status === 'accepted')
        .map(r => r.followerEmail);

    const mutuals: any[] = [];
    const usersArray = Object.values(users);

    for (const targetUsername of iFollowUsernames) {
        const targetUserEntry = usersArray.find(u => u.profile?.name === targetUsername);
        if (targetUserEntry) {
            if (usersFollowingMeEmails.includes(targetUserEntry.email)) {
                mutuals.push({
                    id: targetUserEntry.email,
                    name: targetUserEntry.profile?.nickname || targetUserEntry.profile?.name || 'User',
                    username: targetUserEntry.profile?.name || '',
                    avatar: targetUserEntry.profile?.photoUrl || ''
                });
            }
        }
    }

    return mutuals;
  },

  getTopCreators: async (): Promise<(User & { followerCount: number })[]> => {
      // MODO OFFLINE: Cálculo Local
      const allUsers = db.users.getAll();
      const allRels = db.relationships.getAll();
      
      const followerCounts: Record<string, number> = {};
      allRels.forEach(rel => {
          if (rel.status === 'accepted') {
              const t = rel.followingUsername.toLowerCase();
              followerCounts[t] = (followerCounts[t] || 0) + 1;
          }
      });

      return Object.values(allUsers).map(u => ({
          ...u,
          followerCount: followerCounts[u.profile?.name.toLowerCase() || ''] || 0
      })).sort((a, b) => b.followerCount - a.followerCount).slice(0, 20);
  }
};
