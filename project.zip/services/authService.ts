
import { User, AuthError, VerificationSession, PaymentProviderConfig, UserProfile, NotificationSettings, SecuritySettings, UserSession } from '../types';
import { emailService } from './emailService';
import { cryptoService } from './cryptoService';
import { db } from '@/database'; // Importando o banco local

export const authService = {
  isValidEmail: (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  // === OFFLINE LOGIN ===
  login: async (email: string, password: string): Promise<{ user: User; nextStep: string }> => {
    try {
        const hashedPassword = await cryptoService.hashPassword(password);
        
        // Busca usuário no banco local (SQLite/IndexedDB)
        const user = db.users.get(email);

        if (!user) {
            throw new Error(AuthError.USER_NOT_FOUND);
        }

        if (user.password !== hashedPassword) {
            throw new Error(AuthError.WRONG_PASSWORD);
        }

        // Simula Token e Sessão
        localStorage.setItem('auth_token', 'offline-demo-token');
        localStorage.setItem('user_email', user.email);
        
        if (!user.isProfileCompleted) return { user: user, nextStep: '/complete-profile' };
        return { user: user, nextStep: '/feed' };

    } catch (e: any) {
        throw new Error(e.message || AuthError.GENERIC);
    }
  },

  // === OFFLINE REGISTER ===
  register: async (email: string, password: string) => {
    try {
        // Verifica se já existe localmente
        if (db.users.exists(email)) {
            throw new Error(AuthError.ALREADY_EXISTS);
        }
        
        const hashedPassword = await cryptoService.hashPassword(password);
        
        // Guarda temporariamente para verificação
        sessionStorage.setItem('temp_register_email', email);
        sessionStorage.setItem('temp_register_pw', hashedPassword);
        
        // Simula envio de email (console log)
        console.log(`[OFFLINE] Código enviado para ${email}`);
        await authService.sendVerificationCode(email);

    } catch (e: any) {
        throw new Error(e.message || AuthError.GENERIC);
    }
  },

  // === VERIFY & SAVE LOCAL ===
  verifyCode: async (email: string, code: string, isResetFlow: boolean = false) => {
    const sessionStr = localStorage.getItem(`verify_${email}`);
    const session = sessionStr ? JSON.parse(sessionStr) : null;
    
    // No modo offline de design, podemos aceitar qualquer código '123456' para facilitar testes
    const isDevBypass = code === '123456';

    if (!isDevBypass) {
        if (!session) throw new Error(AuthError.CODE_EXPIRED);
        if (Date.now() > session.expiresAt) throw new Error(AuthError.CODE_EXPIRED);
        if (session.code !== code) throw new Error(AuthError.CODE_INVALID);
    }

    if (!isResetFlow) {
        const passwordHash = sessionStorage.getItem('temp_register_pw');
        if (!passwordHash) throw new Error("Erro de sessão. Tente registrar novamente.");

        const newUser: User = {
            email,
            password: passwordHash,
            isVerified: true,
            isProfileCompleted: false,
            profile: {
                name: email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, ''),
                nickname: 'Novo Usuário',
                isPrivate: false
            },
            notificationSettings: {
                pauseAll: false, likes: true, comments: true, followers: true, mentions: true, messages: true, email: true, groups: true
            },
            securitySettings: {
                saveLoginInfo: true
            },
            sessions: []
        };

        // Salva no banco local
        db.users.set(newUser);

        // Auto login
        localStorage.setItem('user_email', email);
        localStorage.setItem('auth_token', 'offline-token');
        
        sessionStorage.removeItem('temp_register_email');
        sessionStorage.removeItem('temp_register_pw');
    }
    
    return true;
  },

  sendVerificationCode: async (email: string, type: 'register' | 'reset' = 'register') => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    console.log(`[OFFLINE MODE] Seu código de verificação é: ${code}`);
    alert(`[Modo Design Offline] Seu código é: ${code}`);
    
    const session = {
        code,
        expiresAt: Date.now() + 10 * 60 * 1000,
        attempts: 0
    };
    localStorage.setItem(`verify_${email}`, JSON.stringify(session));
  },

  // === OFFLINE PROFILE UPDATE ===
  completeProfile: async (email: string, data: UserProfile) => {
      const user = db.users.get(email);
      if (!user) throw new Error("Usuário não encontrado.");

      const updatedUser = {
          ...user,
          isProfileCompleted: true,
          profile: { ...user.profile, ...data }
      };

      db.users.set(updatedUser);
      return updatedUser;
  },

  checkUsernameAvailability: async (username: string): Promise<boolean> => {
      const allUsers = db.users.getAll();
      const exists = Object.values(allUsers).some(u => u.profile?.name === username);
      return !exists;
  },

  getCurrentUserEmail: () => localStorage.getItem('user_email'),
  
  getCurrentUser: (): User | null => {
    const email = localStorage.getItem('user_email');
    if (!email) return null;
    return db.users.get(email) || null;
  },

  getAllUsers: (): User[] => {
      const usersMap = db.users.getAll();
      return Object.values(usersMap);
  },

  searchUsers: async (query: string): Promise<User[]> => {
      const usersMap = db.users.getAll();
      const term = query.toLowerCase();
      return Object.values(usersMap).filter(u => 
          u.profile?.name?.toLowerCase().includes(term) || 
          u.profile?.nickname?.toLowerCase().includes(term)
      );
  },

  getUserByHandle: (handle: string): User | undefined => {
      const cleanHandle = handle.replace('@', '').toLowerCase();
      const usersMap = db.users.getAll();
      return Object.values(usersMap).find(u => u.profile?.name === cleanHandle);
  },
  
  logout: () => {
    localStorage.removeItem('user_email');
    localStorage.removeItem('auth_token');
  },

  updatePaymentConfig: async (config: PaymentProviderConfig) => {
      const user = authService.getCurrentUser();
      if(user) {
          user.paymentConfig = config;
          db.users.set(user);
      }
  },
  
  updateNotificationSettings: (settings: NotificationSettings) => {
      const user = authService.getCurrentUser();
      if(user) {
          user.notificationSettings = settings;
          db.users.set(user);
      }
  },
  
  updateSecuritySettings: (settings: SecuritySettings) => {
      const user = authService.getCurrentUser();
      if(user) {
          user.securitySettings = settings;
          db.users.set(user);
      }
  },
  
  updateHeartbeat: () => {
      const user = authService.getCurrentUser();
      if(user) {
          user.lastSeen = Date.now();
          db.users.set(user);
      }
  },
  
  getUserSessions: () => [],
  revokeOtherSessions: async () => {},
  
  resetPassword: async (email: string, newPass: string) => {
      const user = db.users.get(email);
      if(user) {
          user.password = await cryptoService.hashPassword(newPass);
          db.users.set(user);
      }
  },
  
  changePassword: async (currentPass: string, newPass: string) => {
      const user = authService.getCurrentUser();
      if (!user) throw new Error("Não autenticado");
      
      const currentHash = await cryptoService.hashPassword(currentPass);
      if (user.password !== currentHash) throw new Error("Senha atual incorreta");
      
      user.password = await cryptoService.hashPassword(newPass);
      db.users.set(user);
  },
  
  loginWithGoogle: async (): Promise<{ user: User; nextStep: string }> => {
      // Mock Google Login for Offline Design
      const email = "google_user@test.com";
      if (!db.users.exists(email)) {
          const newUser: User = {
              email,
              isVerified: true,
              isProfileCompleted: true,
              profile: {
                  name: 'googleuser',
                  nickname: 'Google User',
                  photoUrl: 'https://lh3.googleusercontent.com/a/default-user',
                  isPrivate: false
              },
              password: 'google-mock-pass'
          };
          db.users.set(newUser);
      }
      localStorage.setItem('user_email', email);
      return { user: db.users.get(email)!, nextStep: '/feed' };
  }
};
