
/**
 * Serviço de E-mail - MODO OFFLINE (APK DEMO)
 * Simula envio de e-mail com alertas para testes de design.
 */

export const emailService = {
    /**
     * Simula envio de código de verificação
     */
    sendVerificationCode: async (email: string, code: string, type: 'register' | 'reset' = 'register') => {
        console.log(`[OFFLINE EMAIL] Para: ${email}, Código: ${code}`);
        
        // Simula delay de rede
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Exibe o código na tela para o usuário (Design Test)
        alert(`[SIMULAÇÃO DE EMAIL]\n\nPara: ${email}\nAssunto: ${type === 'reset' ? 'Redefinir Senha' : 'Verificar Conta'}\n\nSeu código é: ${code}`);
    },

    /**
     * Wrapper para reset
     */
    sendPasswordResetCode: async (email: string, code: string) => {
        return emailService.sendVerificationCode(email, code, 'reset');
    }
};
