
import { Post, Comment, PaginatedResponse } from '../types';
import { authService } from './authService';
import { db } from '@/database';

export const postService = {
  getFeedPaginated: async (options: { limit: number; cursor?: number | string; allowedTypes?: string[]; locationFilter?: string | null; allowAdultContent?: boolean }): Promise<PaginatedResponse<Post>> => {
    // OFFLINE FETCH
    const allPosts = db.posts.getAll();
    let filtered = allPosts.sort((a, b) => b.timestamp - a.timestamp);

    if (options.allowedTypes) {
        filtered = filtered.filter(p => options.allowedTypes!.includes(p.type));
    }
    
    if (options.locationFilter) {
        filtered = filtered.filter(p => p.location && p.location.includes(options.locationFilter!));
    }

    if (!options.allowAdultContent) {
        filtered = filtered.filter(p => !p.isAdultContent);
    }

    // Pagination Mock
    let startIndex = 0;
    if (options.cursor) {
        const idx = filtered.findIndex(p => p.timestamp === options.cursor);
        if (idx !== -1) startIndex = idx + 1;
    }

    const sliced = filtered.slice(startIndex, startIndex + options.limit);
    const nextCursor = sliced.length > 0 ? sliced[sliced.length - 1].timestamp : undefined;

    return { data: sliced, nextCursor };
  },

  uploadMedia: async (file: File): Promise<string> => {
      // OFFLINE UPLOAD: Converte para Base64 localmente
      return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
      });
  },

  addPost: async (post: Post) => {
    db.posts.add(post);
  },

  toggleLike: async (postId: string): Promise<Post | undefined> => {
    const userEmail = authService.getCurrentUserEmail();
    if (!userEmail) return undefined;

    const post = db.posts.findById(postId);
    if (!post) return undefined;

    // Local Toggle Logic
    // Nota: A estrutura de 'post' no DB local não tem 'likedBy' tipado no TS original, 
    // mas o db manager lida com isso dinamicamente. Vamos simular aqui.
    const likedBy = (post as any).likedBy || [];
    const index = likedBy.indexOf(userEmail);
    
    if (index === -1) {
        likedBy.push(userEmail);
        post.likes++;
        post.liked = true;
    } else {
        likedBy.splice(index, 1);
        post.likes = Math.max(0, post.likes - 1);
        post.liked = false;
    }
    (post as any).likedBy = likedBy;
    
    db.posts.update(post);
    return post;
  },

  addComment: (postId: string, commentText: string, username: string, avatar?: string): Comment | undefined => {
    const post = db.posts.findById(postId);
    if (!post) return undefined;

    const newComment: Comment = {
        id: Date.now().toString(),
        username, 
        text: commentText, 
        avatar, 
        timestamp: Date.now(), 
        likes: 0, 
        likedByMe: false, 
        replies: []
    };

    if (!post.commentsList) post.commentsList = [];
    post.commentsList.unshift(newComment);
    post.comments = post.commentsList.length;

    db.posts.update(post);
    return newComment;
  },

  getPostById: (id: string): Post | undefined => {
      return db.posts.findById(id);
  },

  getUserPosts: (username: string): Post[] => {
      const all = db.posts.getAll();
      return all.filter(p => p.username === username);
  },

  deletePost: async (postId: string) => {
      db.posts.delete(postId);
  },

  incrementView: (postId: string, userEmail?: string) => {
      const post = db.posts.findById(postId);
      if(post) {
          post.views++;
          if (userEmail) {
              if(!post.viewedBy) post.viewedBy = [];
              if(!post.viewedBy.includes(userEmail)) post.viewedBy.push(userEmail);
          }
          db.posts.update(post);
      }
  },

  addReply: (postId: string, parentId: string, text: string, username: string, avatar?: string): Comment | undefined => {
      const post = db.posts.findById(postId);
      if (!post || !post.commentsList) return undefined;

      const parent = post.commentsList.find(c => c.id === parentId);
      if (parent) {
          const reply: Comment = {
              id: Date.now().toString(),
              text,
              username,
              avatar,
              timestamp: Date.now(),
              likes: 0
          };
          if (!parent.replies) parent.replies = [];
          parent.replies.push(reply);
          post.comments++; // Increment total comments
          db.posts.update(post);
          return reply;
      }
      return undefined;
  },

  toggleCommentLike: (postId: string, commentId: string) => {
      const post = db.posts.findById(postId);
      if (!post || !post.commentsList) return false;

      // Recursive finder
      const toggle = (list: Comment[]): boolean => {
          for (const c of list) {
              if (c.id === commentId) {
                  c.likedByMe = !c.likedByMe;
                  c.likes = (c.likes || 0) + (c.likedByMe ? 1 : -1);
                  return true;
              }
              if (c.replies && toggle(c.replies)) return true;
          }
          return false;
      };

      if (toggle(post.commentsList)) {
          db.posts.update(post);
          return true;
      }
      return false;
  }
};
