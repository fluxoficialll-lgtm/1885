
import { Group, GroupLink, User } from '../types';
import { authService } from './authService';
import { db } from '@/database';

export const groupService = {
  getGroups: async (): Promise<Group[]> => {
    return db.groups.getAll();
  },

  getGroupsSync: (): Group[] => {
      return db.groups.getAll();
  },

  getAllGroupsForRanking: async (): Promise<Group[]> => {
      return db.groups.getAll();
  },

  createGroup: async (group: Group) => {
    db.groups.add(group);
    return true;
  },

  getGroupById: (id: string): Group | undefined => {
      return db.groups.findById(id);
  },

  updateGroup: async (g: Group) => {
      db.groups.update(g);
  },

  deleteGroup: (id: string) => {
      db.groups.delete(id);
  },

  joinGroup: (id: string): 'joined' | 'pending' | 'full' | 'banned' | 'error' => {
      const group = db.groups.findById(id);
      const email = authService.getCurrentUserEmail();
      if (!group || !email) return 'error';

      if (group.bannedUsers?.includes(email)) return 'banned';
      if (group.settings?.memberLimit && (group.members?.length || 0) >= group.settings.memberLimit) return 'full';

      if (group.isPrivate || group.settings?.approveMembers) {
          if (!group.pendingMembers) group.pendingMembers = [];
          if (!group.pendingMembers.includes(email)) {
              group.pendingMembers.push(email);
              db.groups.update(group);
          }
          return 'pending';
      } else {
          if (!group.members) group.members = [];
          if (!group.members.includes(email)) {
              group.members.push(email);
              db.groups.update(group);
          }
          return 'joined';
      }
  },

  joinGroupByLinkCode: (code: string): { success: boolean; message: string; groupId?: string } => {
      const allGroups = db.groups.getAll();
      for (const g of allGroups) {
          if (g.links) {
              const link = g.links.find(l => l.code === code);
              if (link) {
                  // Check validity
                  if (link.maxUses && link.joins >= link.maxUses) return { success: false, message: 'Link expirado (limite de uso).' };
                  
                  // Join
                  const res = groupService.joinGroup(g.id);
                  if (res === 'joined' || res === 'pending') {
                      link.joins++;
                      db.groups.update(g);
                      return { success: true, message: res === 'pending' ? 'Solicitação enviada!' : 'Você entrou no grupo!', groupId: g.id };
                  }
                  return { success: false, message: 'Não foi possível entrar.' };
              }
          }
      }
      return { success: false, message: 'Código inválido.' };
  },

  leaveGroup: (id: string) => {
      const group = db.groups.findById(id);
      const email = authService.getCurrentUserEmail();
      if (group && email && group.members) {
          group.members = group.members.filter(m => m !== email);
          db.groups.update(group);
      }
  },

  removeMember: (gid: string, email: string) => {
      const group = db.groups.findById(gid);
      if (group && group.members) {
          group.members = group.members.filter(m => m !== email);
          db.groups.update(group);
      }
  },

  banMember: (gid: string, email: string) => {
      const group = db.groups.findById(gid);
      if (group) {
          if (group.members) group.members = group.members.filter(m => m !== email);
          if (!group.bannedUsers) group.bannedUsers = [];
          group.bannedUsers.push(email);
          db.groups.update(group);
      }
  },

  promoteMember: (gid: string, email: string) => {
      const group = db.groups.findById(gid);
      if (group) {
          if (!group.admins) group.admins = [];
          if (!group.admins.includes(email)) group.admins.push(email);
          db.groups.update(group);
      }
  },

  demoteMember: (gid: string, email: string) => {
      const group = db.groups.findById(gid);
      if (group && group.admins) {
          group.admins = group.admins.filter(a => a !== email);
          db.groups.update(group);
      }
  },

  getGroupMembers: (gid: string): User[] => {
      const group = db.groups.findById(gid);
      if (!group || !group.members) return [];
      
      const allUsers = db.users.getAll();
      return group.members.map(email => allUsers[email]).filter(Boolean);
  },

  getPendingMembers: (gid: string): User[] => {
      const group = db.groups.findById(gid);
      if (!group || !group.pendingMembers) return [];
      
      const allUsers = db.users.getAll();
      return group.pendingMembers.map(email => allUsers[email]).filter(Boolean);
  },

  approveMember: (gid: string, email: string) => {
      const group = db.groups.findById(gid);
      if (group) {
          if (group.pendingMembers) group.pendingMembers = group.pendingMembers.filter(m => m !== email);
          if (!group.members) group.members = [];
          if (!group.members.includes(email)) group.members.push(email);
          db.groups.update(group);
      }
  },

  rejectMember: (gid: string, email: string) => {
      const group = db.groups.findById(gid);
      if (group && group.pendingMembers) {
          group.pendingMembers = group.pendingMembers.filter(m => m !== email);
          db.groups.update(group);
      }
  },

  addGroupLink: (gid: string, name: string, maxUses?: number, expiresAt?: string) => {
      const group = db.groups.findById(gid);
      if (!group) return null;
      
      const newLink: GroupLink = {
          id: Date.now().toString(),
          name,
          code: Math.random().toString(36).substring(2, 8).toUpperCase(),
          joins: 0,
          createdAt: Date.now(),
          maxUses,
          expiresAt
      };
      
      if (!group.links) group.links = [];
      group.links.push(newLink);
      db.groups.update(group);
      return newLink;
  },

  removeGroupLink: (gid: string, lid: string) => {
      const group = db.groups.findById(gid);
      if (group && group.links) {
          group.links = group.links.filter(l => l.id !== lid);
          db.groups.update(group);
      }
  }
};
