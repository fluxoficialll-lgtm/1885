
import { User, Group } from '../types';

/**
 * SyncPay Service - MODO OFFLINE (APK DEMO)
 * Simula transações financeiras locais para teste de UI/UX.
 */

export const syncPayService = {

    getFees: async (): Promise<{ withdrawal_fee: number; platform_fee: number }> => {
        return { withdrawal_fee: 5.00, platform_fee: 3.00 };
    },

    authenticate: async (clientId: string, clientSecret: string): Promise<void> => {
        await new Promise(resolve => setTimeout(resolve, 1000));
        if (!clientId || !clientSecret) throw new Error("Credenciais inválidas simuladas.");
        return; // Sucesso
    },

    createPayment: async (payer: User, group: Group): Promise<{pixCode: string, identifier: string, qrCodeImage?: string}> => {
        await new Promise(resolve => setTimeout(resolve, 2000)); // Delay para spinner
        
        const mockPix = "00020126580014BR.GOV.BCB.PIX0136123e4567-e89b-12d3-a456-426614174000520400005303986540510.005802BR5913Flux Platform6008Brasilia62070503***6304E2CA";
        
        return {
            pixCode: mockPix,
            identifier: `mock_tx_${Date.now()}`,
            qrCodeImage: `https://quickchart.io/qr?text=${encodeURIComponent(mockPix)}&size=300&margin=2&ecLevel=L&dark=000000&light=ffffff`
        };
    },

    requestWithdrawal: async (user: User, amount: number, pixKey: string, pixKeyType: string): Promise<any> => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        return { status: 'success', id: `withdraw_${Date.now()}` };
    },

    checkTransactionStatus: async (identifier: string, sellerEmail: string): Promise<'pending' | 'paid' | 'expired' | 'completed'> => {
        // Simula aprovação automática após 3 segundos
        await new Promise(resolve => setTimeout(resolve, 1500));
        return 'completed';
    },

    getBalance: async (email: string): Promise<number> => {
        return 1250.50; // Saldo Mock
    },

    getTransactions: async (email: string): Promise<any[]> => {
        return [
            { id: '1', amount: 49.90, status: 'paid', created_at: new Date().toISOString(), description: 'Venda Grupo VIP' },
            { id: '2', amount: 49.90, status: 'paid', created_at: new Date(Date.now() - 86400000).toISOString(), description: 'Venda Grupo VIP' },
            { id: '3', amount: 29.90, status: 'paid', created_at: new Date(Date.now() - 172800000).toISOString(), description: 'Venda Ebook' }
        ];
    }
};
