

import React, { useState, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { marketplaceService } from '../services/marketplaceService';
import { authService } from '../services/authService';
import { MarketplaceItem } from '../types';

const SELECTABLE_CATEGORIES = [
    { id: 'Eletrônicos', icon: 'fa-mobile-screen', label: 'Eletrônicos' },
    { id: 'Moda', icon: 'fa-shirt', label: 'Moda' },
    { id: 'Casa', icon: 'fa-couch', label: 'Casa' },
    { id: 'Automotivo', icon: 'fa-car', label: 'Automotivo' },
    { id: 'Imóveis', icon: 'fa-building', label: 'Imóveis' },
    { id: 'Serviços', icon: 'fa-screwdriver-wrench', label: 'Serviços' },
    { id: 'Infoprodutos', icon: 'fa-graduation-cap', label: 'Infoprodutos' },
    { id: 'Vagas de Emprego', icon: 'fa-briefcase', label: 'Empregos' },
];

export const CreateMarketplaceItem: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as { type?: 'paid' | 'organic' } | null;
  const isPaid = state?.type === 'paid';
  
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('Eletrônicos');
  const [locationVal, setLocationVal] = useState('');
  const [description, setDescription] = useState('');
  
  // Media State
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [additionalImages, setAdditionalImages] = useState<string[]>([]);
  const [video, setVideo] = useState<string | null>(null);
  
  // Ad Budget for Paid
  const [adBudget, setAdBudget] = useState('');

  const coverInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Handlers
  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setCoverImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleGalleryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (!files) return;
      
      const fileArray = Array.from(files).slice(0, 5 - additionalImages.length); // Limit total to 5
      
      fileArray.forEach(file => {
          const reader = new FileReader();
          reader.onload = (ev) => {
              if(ev.target?.result) {
                  setAdditionalImages(prev => [...prev, ev.target!.result as string]);
              }
          };
          reader.readAsDataURL(file as Blob);
      });
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onload = (ev) => setVideo(ev.target?.result as string);
          reader.readAsDataURL(file);
      }
  };

  const removeGalleryImage = (index: number) => {
      setAdditionalImages(prev => prev.filter((_, i) => i !== index));
  };

  const removeVideo = () => {
      setVideo(null);
      if (videoInputRef.current) videoInputRef.current.value = '';
  };

  // Currency Mask
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let value = e.target.value;
      value = value.replace(/\D/g, "");
      if (value === "") { setPrice(""); return; }
      const numericValue = parseFloat(value) / 100;
      setPrice(numericValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !price || !locationVal || !coverImage) {
        alert("Preencha os campos obrigatórios e adicione uma capa.");
        return;
    }
    
    // Parse price for save
    const rawPrice = price.replace(/\./g, '').replace(',', '.');
    const numericPrice = parseFloat(rawPrice);

    if (isPaid && (!adBudget || parseFloat(adBudget) < 10)) {
        alert("Orçamento mínimo para destaque é R$ 10,00.");
        return;
    }

    const currentUser = authService.getCurrentUser();
    if (!currentUser) return;

    const newItem: MarketplaceItem = {
        id: Date.now().toString(),
        title,
        price: numericPrice,
        category,
        location: locationVal,
        description,
        image: coverImage, // Main Cover
        images: additionalImages, // Extra Photos
        video: video || undefined, // Optional Video
        sellerId: currentUser.email,
        sellerName: currentUser.profile?.name || 'Usuário',
        sellerAvatar: currentUser.profile?.photoUrl,
        timestamp: Date.now(),
        soldCount: 0 
    };

    marketplaceService.createItem(newItem);
    
    alert(`Anúncio ${isPaid ? 'patrocinado' : ''} publicado com sucesso!`);
    navigate('/marketplace');
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        
        header {
            display:flex; align-items:center; justify-content:space-between; padding:16px;
            background: #0c0f14; position:fixed; width:100%; top:0; z-index:10;
            border-bottom:1px solid rgba(255,255,255,0.1); height: 65px;
        }
        header .back-btn {
            background:none; border:none; color:#fff; font-size:20px; cursor:pointer; padding-right: 15px;
        }
        header h1 { font-size:18px; font-weight:600; color: #fff; }

        main { 
            padding-top: 85px; 
            padding-bottom: 40px; 
            width: 100%; 
            max-width: 600px; 
            margin: 0 auto; 
            padding-left: 20px; 
            padding-right: 20px;
            flex-grow: 1;
            overflow-y: auto; 
            -webkit-overflow-scrolling: touch;
        }

        /* Section Styling */
        .section-label {
            font-size: 14px; font-weight: 600; color: #00c2ff; margin-bottom: 12px;
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .form-section {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
        }

        /* Media Upload */
        .media-container {
            display: flex; flex-direction: column; gap: 15px;
        }
        .main-cover-upload {
            width: 100%; aspect-ratio: 16/9; background: #1a1e26;
            border: 2px dashed rgba(255,255,255,0.1); border-radius: 12px;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            cursor: pointer; overflow: hidden; position: relative; transition: 0.3s;
        }
        .main-cover-upload:hover { border-color: #00c2ff; background: rgba(0,194,255,0.05); }
        .main-cover-upload img { width: 100%; height: 100%; object-fit: cover; }
        .upload-hint { text-align: center; color: #aaa; font-size: 13px; }
        .upload-hint i { font-size: 24px; margin-bottom: 8px; display: block; color: #00c2ff; }

        .gallery-scroll {
            display: flex; gap: 10px; overflow-x: auto; padding-bottom: 5px;
        }
        .gallery-item {
            width: 70px; height: 70px; border-radius: 8px; flex-shrink: 0;
            background: #111; position: relative; overflow: hidden; border: 1px solid rgba(255,255,255,0.1);
        }
        .gallery-item img, .gallery-item video { width: 100%; height: 100%; object-fit: cover; }
        
        .add-btn-small {
            width: 70px; height: 70px; border-radius: 8px; flex-shrink: 0;
            background: rgba(255,255,255,0.05); border: 1px dashed rgba(255,255,255,0.2);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; color: #aaa; font-size: 20px; transition: 0.2s;
        }
        .add-btn-small:hover { border-color: #00c2ff; color: #00c2ff; }
        
        .remove-media {
            position: absolute; top: 2px; right: 2px; background: rgba(0,0,0,0.7);
            color: #ff4d4d; border: none; width: 18px; height: 18px; border-radius: 50%;
            font-size: 10px; cursor: pointer; display: flex; align-items: center; justify-content: center;
        }

        /* Inputs */
        .input-group { margin-bottom: 20px; }
        .input-group:last-child { margin-bottom: 0; }
        
        .input-wrapper { position: relative; }
        .input-wrapper input, .input-wrapper textarea, .input-wrapper select {
            width: 100%; background: #14171d; border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px; padding: 14px; color: #fff; font-size: 15px; outline: none;
            transition: 0.3s;
        }
        .input-wrapper input:focus, .input-wrapper textarea:focus, .input-wrapper select:focus {
            border-color: #00c2ff; background: #1a1e26;
        }
        .input-label {
            position: absolute; left: 14px; top: -8px; background: #1a1e26; padding: 0 5px;
            font-size: 11px; color: #00c2ff; font-weight: 600; border-radius: 4px;
        }
        
        .row-inputs { display: flex; gap: 15px; }
        .row-inputs .input-group { flex: 1; }

        /* Category List */
        .category-list {
            display: flex; gap: 10px; overflow-x: auto; padding-bottom: 10px; margin-bottom: 10px;
        }
        .cat-chip {
            padding: 8px 16px; border-radius: 20px; background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1); color: #aaa; font-size: 13px;
            white-space: nowrap; cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 6px;
        }
        .cat-chip:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .cat-chip.active {
            background: rgba(0,194,255,0.15); border-color: #00c2ff; color: #00c2ff; font-weight: 600;
        }

        /* Submit Button */
        .submit-btn {
            width: 100%; padding: 16px; background: #00c2ff; color: #000; border: none;
            border-radius: 12px; font-weight: 700; font-size: 16px; cursor: pointer;
            box-shadow: 0 4px 15px rgba(0,194,255,0.3); transition: 0.3s;
        }
        .submit-btn:hover { background: #0099cc; transform: translateY(-2px); }
        .submit-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; background: #333; color: #777; box-shadow: none; }

        /* Paid Mode Highlight */
        .paid-section {
            border: 1px solid #FFD700; background: rgba(255, 215, 0, 0.05);
        }
        .paid-label { color: #FFD700 !important; }
      `}</style>

      <header>
        <button onClick={() => navigate('/marketplace')} className="back-btn"><i className="fa-solid fa-arrow-left"></i></button>
        <h1>{isPaid ? 'Criar Destaque' : 'Publicar Produto'}</h1>
        <div style={{width:'20px'}}></div>
      </header>

      <main>
        <form onSubmit={handleSubmit}>
            
            {/* 1. VISUALS */}
            <div className="form-section">
                <div className="section-label">Fotos & Vídeo</div>
                <div className="media-container">
                    {/* Cover */}
                    <div className="main-cover-upload" onClick={() => coverInputRef.current?.click()}>
                        {coverImage ? (
                            <img src={coverImage} alt="Capa" />
                        ) : (
                            <div className="upload-hint">
                                <i className="fa-solid fa-camera"></i>
                                <span>Adicionar Capa Principal</span>
                            </div>
                        )}
                        <input type="file" ref={coverInputRef} hidden accept="image/*" onChange={handleCoverChange} />
                    </div>

                    {/* Gallery List */}
                    <div className="gallery-scroll">
                        {additionalImages.map((img, idx) => (
                            <div key={`img-${idx}`} className="gallery-item">
                                <img src={img} alt="Thumb" />
                                <button type="button" className="remove-media" onClick={() => removeGalleryImage(idx)}>
                                    <i className="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        ))}
                        
                        {video && (
                            <div className="gallery-item">
                                <video src={video} />
                                <button type="button" className="remove-media" onClick={removeVideo}>
                                    <i className="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                        )}

                        {additionalImages.length < 5 && (
                            <div className="add-btn-small" onClick={() => galleryInputRef.current?.click()} title="Adicionar Foto">
                                <i className="fa-solid fa-image"></i>
                            </div>
                        )}
                        {!video && (
                            <div className="add-btn-small" onClick={() => videoInputRef.current?.click()} title="Adicionar Vídeo">
                                <i className="fa-solid fa-video"></i>
                            </div>
                        )}
                        
                        <input type="file" ref={galleryInputRef} hidden accept="image/*" multiple onChange={handleGalleryChange} />
                        <input type="file" ref={videoInputRef} hidden accept="video/*" onChange={handleVideoChange} />
                    </div>
                </div>
            </div>

            {/* 2. BASIC INFO */}
            <div className="form-section">
                <div className="section-label">Informações Básicas</div>
                
                <div className="input-group">
                    <div className="input-wrapper">
                        <span className="input-label">Título do Anúncio</span>
                        <input 
                            type="text" 
                            placeholder="Ex: iPhone 13 Pro Max, Vaga de Designer..." 
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            maxLength={60}
                        />
                    </div>
                </div>

                <div className="row-inputs">
                    <div className="input-group">
                        <div className="input-wrapper">
                            <span className="input-label">Preço (R$)</span>
                            <input 
                                type="text" 
                                placeholder="0,00" 
                                value={price}
                                onChange={handlePriceChange}
                            />
                        </div>
                    </div>
                    <div className="input-group">
                        <div className="input-wrapper">
                            <span className="input-label">Cidade</span>
                            <input 
                                type="text" 
                                placeholder="Ex: São Paulo" 
                                value={locationVal}
                                onChange={(e) => setLocationVal(e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* 3. DETAILS & CATEGORY */}
            <div className="form-section">
                <div className="section-label">Categoria</div>
                <div className="category-list">
                    {SELECTABLE_CATEGORIES.map(cat => (
                        <div 
                            key={cat.id} 
                            className={`cat-chip ${category === cat.id ? 'active' : ''}`}
                            onClick={() => setCategory(cat.id)}
                        >
                            <i className={`fa-solid ${cat.icon}`}></i> {cat.label}
                        </div>
                    ))}
                </div>

                <div className="input-group" style={{marginTop: '20px'}}>
                    <div className="input-wrapper">
                        <span className="input-label">Descrição</span>
                        <textarea 
                            rows={4}
                            placeholder="Descreva os detalhes do produto, condições de uso, etc..."
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                        ></textarea>
                    </div>
                </div>
            </div>

            {/* 4. BOOST (Conditional) */}
            {isPaid && (
                <div className="form-section paid-section">
                    <div className="section-label paid-label"><i className="fa-solid fa-rocket"></i> Impulsionamento</div>
                    <div className="input-group">
                        <div className="input-wrapper">
                            <span className="input-label paid-label">Orçamento Diário (R$)</span>
                            <input 
                                type="number" 
                                placeholder="Mínimo 10.00" 
                                value={adBudget}
                                onChange={(e) => setAdBudget(e.target.value)}
                                style={{borderColor: '#FFD700'}}
                            />
                        </div>
                        <p style={{fontSize:'12px', color:'#FFD700', marginTop:'5px', opacity:0.8}}>Seu anúncio aparecerá com destaque no topo.</p>
                    </div>
                </div>
            )}

            <button type="submit" className="submit-btn" disabled={!title || !price || !coverImage}>
                {isPaid ? 'Pagar e Destacar' : 'Publicar Agora'}
            </button>

        </form>
      </main>
    </div>
  );
};