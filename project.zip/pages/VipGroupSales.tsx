
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { authService } from '../services/authService';
import { syncPayService } from '../services/syncPayService';
import { db } from '@/database';
import { Group, VipMediaItem } from '../types';

export const VipGroupSales: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [group, setGroup] = useState<Group | null>(null);
  const [loading, setLoading] = useState(true);
  const [isCreator, setIsCreator] = useState(false);
  
  // Payment Logic State (Availability)
  const [isPurchaseEnabled, setIsPurchaseEnabled] = useState(false);

  // Payment States
  const [isPixModalOpen, setIsPixModalOpen] = useState(false);
  const [pixCode, setPixCode] = useState('');
  const [pixImage, setPixImage] = useState<string | undefined>(undefined);
  const [transactionId, setTransactionId] = useState('');
  const [isGeneratingPix, setIsGeneratingPix] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'approved'>('pending');
  const [isChecking, setIsChecking] = useState(false);
  
  // Gift / Redeem State
  const [showGift, setShowGift] = useState(false);
  
  // State for copy feedback
  const [isCopied, setIsCopied] = useState(false);
  const pixTextAreaRef = useRef<HTMLTextAreaElement>(null);
  
  // Carousel State
  const [currentSlide, setCurrentSlide] = useState(0);
  const snapContainerRef = useRef<HTMLDivElement>(null);
  
  // Polling Ref
  const pollingInterval = useRef<any>(null);

  useEffect(() => {
      const loadData = async () => {
          if (id) {
              const foundGroup = groupService.getGroupById(id);
              const currentUserEmail = authService.getCurrentUserEmail();
              
              if (foundGroup) {
                  // --- REDIRECT IF ALREADY HAS ACCESS (Bypass Sales) ---
                  if (currentUserEmail && foundGroup.creatorEmail !== currentUserEmail) {
                      const hasAccess = db.vipAccess.check(currentUserEmail, foundGroup.id);
                      // Também verifica se já é membro (pode ter entrado manualmente)
                      const isMember = foundGroup.members?.includes(currentUserEmail);
                      
                      if (hasAccess && isMember) {
                          navigate(`/group-chat/${id}`, { replace: true });
                          return;
                      }
                  }

                  setGroup(foundGroup);
                  if (currentUserEmail && foundGroup.creatorEmail === currentUserEmail) {
                      setIsCreator(true);
                  }

                  // DYNAMIC CHECK: Is payment enabled?
                  // Check if creator has connected payment provider (SyncPay)
                  if (foundGroup.creatorEmail) {
                      const allUsers = authService.getAllUsers();
                      const creator = allUsers.find(u => u.email === foundGroup.creatorEmail);
                      
                      // Enabled if creator exists and has connected payment config
                      const hasProvider = creator?.paymentConfig?.isConnected;
                      setIsPurchaseEnabled(!!hasProvider);
                  }
              }
          }
          setLoading(false);
      };
      loadData();
      
      return () => stopPolling();
  }, [id]);

  const stopPolling = () => {
      if (pollingInterval.current) {
          clearInterval(pollingInterval.current);
          pollingInterval.current = null;
      }
  };
  
  // --- CONSTRUCT CAROUSEL MEDIA ---
  const displayMedia: VipMediaItem[] = [];
  if (group) {
      // 1. Always add Cover Image first (as requested: 1 capa)
      if (group.coverImage) {
          displayMedia.push({
              url: group.coverImage,
              type: 'image'
          });
      }

      // 2. Add VIP Door items (Photos + Videos)
      if (group.vipDoor?.mediaItems && group.vipDoor.mediaItems.length > 0) {
          displayMedia.push(...group.vipDoor.mediaItems);
      } else if (group.vipDoor?.media) {
          // Legacy support
          displayMedia.push({
              url: group.vipDoor.media,
              type: group.vipDoor.mediaType || 'image'
          });
      }
      
      // Fallback if absolutely nothing exists
      if (displayMedia.length === 0) {
          displayMedia.push({
              url: 'https://placehold.co/400x500/1e293b/00c2ff?text=VIP',
              type: 'image'
          });
      }
  }

  const handleScroll = () => {
      if (snapContainerRef.current) {
          const scrollLeft = snapContainerRef.current.scrollLeft;
          const width = snapContainerRef.current.offsetWidth;
          // Calculate index based on scroll position
          const center = scrollLeft + (width / 2);
          const children = Array.from(snapContainerRef.current.children) as HTMLElement[];
          
          let closestIndex = 0;
          let minDistance = Infinity;

          children.forEach((child, index) => {
              const childCenter = child.offsetLeft + (child.offsetWidth / 2);
              const distance = Math.abs(center - childCenter);
              if (distance < minDistance) {
                  minDistance = distance;
                  closestIndex = index;
              }
          });
          setCurrentSlide(closestIndex);
      }
  };

  const handlePurchaseClick = () => {
      if (isCreator) {
          alert("Você é o dono deste grupo!");
          navigate(`/group-chat/${group?.id}`);
          return;
      }
      
      // Go straight to pix generation
      generatePix();
  };

  const generatePix = async () => {
      const user = authService.getCurrentUser();
      if (!user || !group) return;

      // Open modal and show loading
      setIsPixModalOpen(true);
      setIsGeneratingPix(true);
      setPaymentStatus('pending');
      setShowGift(false);
      setPixCode('');
      setPixImage(undefined);

      try {
          // REAL Payment Request
          const { pixCode, identifier, qrCodeImage } = await syncPayService.createPayment(user, group);
          
          if (!pixCode) throw new Error("Código PIX vazio na resposta do Service.");

          setPixCode(pixCode);
          setTransactionId(identifier);
          setPixImage(qrCodeImage);
          
          setIsGeneratingPix(false);

          // Start Polling Real Status
          startPaymentCheck(identifier);

      } catch (error: any) {
          alert("Erro na geração do PIX: " + error.message);
          setIsPixModalOpen(false);
          setIsGeneratingPix(false);
      }
  };

  const startPaymentCheck = (identifier: string) => {
      stopPolling();
      if (!group || !group.creatorEmail) return;

      const sellerEmail = group.creatorEmail;
      
      pollingInterval.current = setInterval(async () => {
          await checkStatusOnce(identifier, sellerEmail);
      }, 5000); // Check every 5 seconds
  };

  const checkStatusOnce = async (identifier: string, sellerEmail: string) => {
      try {
          setIsChecking(true);
          const status = await syncPayService.checkTransactionStatus(identifier, sellerEmail);
          setIsChecking(false);
          
          if (status === 'completed' || status === 'paid') {
              setPaymentStatus('approved');
              stopPolling();
              // Show Gift Screen instead of auto redirect
              setShowGift(true);
          }
      } catch (e) {
          console.error("Check status error", e);
          setIsChecking(false);
      }
  };

  const handleRedeem = () => {
      if (!group || !authService.getCurrentUserEmail()) return;
      
      // Grant Access in DB
      db.vipAccess.grant({
          userId: authService.getCurrentUserEmail()!,
          groupId: group.id,
          status: 'active',
          purchaseDate: Date.now(),
          transactionId: transactionId
      });

      // Add as Member
      groupService.approveMember(group.id, authService.getCurrentUserEmail()!);

      // Redirect
      navigate(`/group-chat/${group.id}`);
  };

  const copyPixCode = async () => {
    if (!pixCode) return;
    try {
        await navigator.clipboard.writeText(pixCode);
        setIsCopied(true);
        if (pixTextAreaRef.current) {
            pixTextAreaRef.current.select();
        }
        setTimeout(() => {
            setIsCopied(false);
        }, 2000);
    } catch (err) {
        // Fallback manual selection
        if (pixTextAreaRef.current) {
            pixTextAreaRef.current.select();
            document.execCommand('copy');
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        } else {
            alert('Erro ao copiar. Tente selecionar o texto manualmente.');
        }
    }
  };

  const getCurrencySymbol = (currency?: string) => {
    switch (currency) {
      case 'USD': return '$';
      case 'EUR': return '€';
      case 'BTC': return '₿';
      default: return 'R$';
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#0c0f14] text-white">Carregando...</div>;
  
  if (!group) return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0f14] text-white p-5 text-center">
          <h2 className="text-xl font-bold text-gray-500 mb-4">Grupo não encontrado</h2>
          <button onClick={() => navigate('/feed')} className="text-[#00c2ff]">Voltar ao Feed</button>
      </div>
  );

  // Se não tiver imagem do provedor, gerar fallback visual aqui também
  const displayQrCode = pixImage || (pixCode ? `https://quickchart.io/qr?text=${encodeURIComponent(pixCode)}&size=300&margin=2&ecLevel=L&dark=000000&light=ffffff` : null);

  const isInactive = group.status === 'inactive';

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
        <style>{`
            .carousel-wrapper {
                position: relative; width: 100%;
            }
            .snap-container {
                scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch; 
                scrollbar-width: none; display: flex; gap: 10px; overflow-x: auto;
                width: 100%; padding-bottom: 20px;
            }
            .snap-container::-webkit-scrollbar { display: none; }
            .snap-item {
                scroll-snap-align: center; flex-shrink: 0; width: 85vw; max-width: 400px;
                aspect-ratio: 4/5; position: relative; border-radius: 16px;
                overflow: hidden; border: 1px solid rgba(0, 194, 255, 0.3);
                box-shadow: 0 4px 20px rgba(0, 194, 255, 0.2); background: #000;
            }
            .snap-container > .snap-item:first-child { margin-left: 7.5vw; }
            .snap-container > .snap-item:last-child { margin-right: 7.5vw; }
            .snap-item img, .snap-item video { width: 100%; height: 100%; object-fit: cover; }

            .carousel-dots {
                display: flex; justify-content: center; gap: 6px; margin-top: -15px; margin-bottom: 15px;
            }
            .dot {
                width: 6px; height: 6px; border-radius: 50%; background: rgba(255,255,255,0.3);
                transition: all 0.3s;
            }
            .dot.active {
                background: #00c2ff; width: 18px; border-radius: 4px;
            }

            .cta-button {
                background: linear-gradient(90deg, #00c2ff, #00aaff); color: #0c0f14;
                font-weight: 700; padding: 1rem 0; border-radius: 12px; font-size: 1.5rem;
                box-shadow: 0 5px 20px rgba(0, 194, 255, 0.5); transition: transform 0.2s;
                width: 90%; margin-top: 10px; border: none; cursor: pointer;
            }
            .cta-button:active { transform: scale(0.98); }
            .cta-button.disabled {
                background: #333; color: #777; cursor: not-allowed; box-shadow: none; transform: none;
            }

            .content-section { padding: 16px; max-width: 450px; margin: 0 auto; }
            .copy-box {
                background: rgba(0, 194, 255, 0.05); border: 1px solid #00c2ff;
                border-radius: 12px; padding: 20px; margin-top: 20px;
            }

            .modal-overlay {
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background-color: rgba(0, 0, 0, 0.85); display: flex; justify-content: center;
                align-items: center; z-index: 50; opacity: 0; visibility: hidden;
                transition: opacity 0.3s, visibility 0.3s;
            }
            .modal-overlay.open { opacity: 1; visibility: visible; }
            .modal-content {
                background-color: #0c0f14; padding: 25px; border-radius: 16px;
                width: 90%; max-width: 380px; box-shadow: 0 0 40px rgba(0, 194, 255, 0.2);
                border: 1px solid #00c2ff; transform: translateY(-20px); transition: transform 0.3s ease-out;
                max-height: 90vh; overflow-y: auto; text-align: center;
            }
            .modal-overlay.open .modal-content { transform: translateY(0); }

            .pix-textarea {
                background-color: #1a1f26; color: #fff; padding: 12px;
                border-radius: 8px; margin: 15px 0; font-family: monospace;
                font-size: 11px; border: 1px dashed #00c2ff;
                width: 100%; min-height: 120px; resize: none; outline: none;
                word-break: break-all;
            }
            .pix-textarea:focus { border-color: #fff; }
            
            .qrcode-wrapper {
                background: #fff; padding: 10px; border-radius: 12px; margin: 15px auto; display: inline-block;
            }
            .qrcode-img {
                width: 200px; height: 200px; object-fit: contain;
                display: block;
            }
            
            .check-btn {
                background: transparent; border: 1px solid #00c2ff; color: #00c2ff;
                padding: 8px 16px; border-radius: 20px; font-size: 12px; font-weight: 600;
                cursor: pointer; margin-top: 10px; transition: 0.3s;
            }
            .check-btn:hover { background: rgba(0,194,255,0.1); }
            
            .creator-preview-banner {
                background: #ff9800; color: #000; text-align: center; padding: 8px;
                font-weight: bold; font-size: 12px; width: 100%; position: fixed; top: 0; z-index: 20;
            }

            .success-anim { animation: popIn 0.5s ease; }
            @keyframes popIn { 0% { transform: scale(0.5); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
            @keyframes bounceGift {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-15px); }
            }
            .gift-icon {
                font-size: 80px; color: #FFD700; margin-bottom: 20px;
                animation: bounceGift 2s infinite; filter: drop-shadow(0 0 15px rgba(255, 215, 0, 0.5));
            }
            .redeem-btn {
                background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
                color: #000; font-weight: 800; padding: 16px 32px; border-radius: 50px;
                font-size: 18px; border: none; cursor: pointer; margin-top: 20px;
                box-shadow: 0 5px 25px rgba(255, 215, 0, 0.4); text-transform: uppercase; letter-spacing: 1px;
                transition: transform 0.2s; width: 100%;
            }
            .redeem-btn:active { transform: scale(0.95); }
        `}</style>

        {isCreator && (
            <div className="creator-preview-banner">
                <i className="fa-solid fa-eye"></i> Visualização do Membro {isInactive ? '(Grupo Inativo)' : ''}
            </div>
        )}

        <header className="flex items-center justify-between p-[16px_32px] bg-[#0c0f14] fixed w-full z-10 border-b border-white/10" style={{top: isCreator ? '30px' : '0', height: '70px'}}>
            <button onClick={() => navigate('/groups')} className="bg-none border-none text-[#00c2ff] text-lg cursor-pointer"><i className="fa-solid fa-arrow-left"></i></button>
            
            <div className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20">
                 <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
                 <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
            </div>
            
            <div style={{width: '24px'}}></div> 
        </header>

        <main className="w-full pb-[100px]" style={{paddingTop: isCreator ? '120px' : '90px'}}>
            
            <div className="text-center mb-6 px-4">
                <h1 className="text-2xl font-bold text-[#00c2ff] mb-1">{group.name}</h1>
                <div className="flex items-center justify-center gap-2 text-xs text-gray-400 uppercase tracking-widest">
                    <i className="fa-solid fa-lock"></i> Área VIP Exclusiva
                </div>
            </div>

            <div className="carousel-wrapper">
                <div className="snap-container" ref={snapContainerRef} onScroll={handleScroll}>
                    {displayMedia.map((item, index) => (
                        <div key={index} className="snap-item">
                            {item.type === 'video' ? (
                                <video src={item.url} controls controlsList="nodownload" />
                            ) : (
                                <img src={item.url} alt={`Conteúdo VIP ${index + 1}`} />
                            )}
                        </div>
                    ))}
                </div>
                {displayMedia.length > 1 && (
                    <div className="carousel-dots">
                        {displayMedia.map((_, idx) => (
                            <div key={idx} className={`dot ${currentSlide === idx ? 'active' : ''}`}></div>
                        ))}
                    </div>
                )}
            </div>
            
            <section className="content-section">
                <div className="copy-box text-left space-y-4">
                    <p className="text-base text-gray-200 whitespace-pre-wrap leading-relaxed">
                        {group.vipDoor?.text || "Este grupo contém conteúdo exclusivo. Garanta seu acesso agora!"}
                    </p>
                </div>
            </section>

            <section className="content-section text-center pb-10"> 
                <div className="flex flex-col items-center justify-center w-full">
                    {/* BUTTON UPDATED: Depends on `isPurchaseEnabled` derived from creator payment config, NOT just `group.status` */}
                    <button 
                        className={`cta-button ${!isPurchaseEnabled ? 'disabled' : ''}`} 
                        onClick={!isPurchaseEnabled ? undefined : handlePurchaseClick}
                        disabled={!isPurchaseEnabled}
                    >
                        {!isPurchaseEnabled ? 'COMPRA INDISPONÍVEL' : `COMPRAR AGORA (${getCurrencySymbol(group.currency)} ${group.price || '0.00'})`}
                    </button>
                    {!isPurchaseEnabled && (
                        <p className="text-xs text-red-400 mt-2">
                            * O dono deste grupo ainda não configurou os pagamentos.
                        </p>
                    )}
                    <p className="text-xs text-gray-500 mt-3 flex items-center gap-1">
                        <i className="fa-solid fa-shield-halved"></i> Processado por SyncPay
                    </p>
                </div>
            </section>

        </main>

        {/* MODAL DE PAGAMENTO & PRESENTE */}
        <div className={`modal-overlay ${isPixModalOpen ? 'open' : ''}`} onClick={(e) => { if(e.target === e.currentTarget && !showGift) { setIsPixModalOpen(false); stopPolling(); } }}>
            <div className="modal-content">
                
                {isGeneratingPix ? (
                    /* LOADING */
                    <div className="py-10">
                        <i className="fa-solid fa-circle-notch fa-spin text-4xl text-[#00c2ff]"></i>
                        <p className="mt-4 text-gray-400">Gerando PIX...</p>
                    </div>
                ) : showGift ? (
                    /* GIFT SCREEN (NOVO!) */
                    <div className="py-5 success-anim flex flex-col items-center">
                        <i className="fa-solid fa-gift gift-icon"></i>
                        <h3 className="text-2xl font-extrabold text-white mb-2">Presente Liberado!</h3>
                        <p className="text-gray-300 text-sm mb-6 px-4">
                            Seu pagamento foi confirmado. O grupo VIP está esperando por você.
                        </p>
                        <button className="redeem-btn" onClick={handleRedeem}>
                            RESGATAR ACESSO
                        </button>
                    </div>
                ) : (
                    /* PIX DISPLAY */
                    <>
                        <h3 className="text-lg font-bold text-[#00c2ff] mb-2">Pagar com Pix</h3>
                        <p className="text-xs text-gray-400 mb-2">Valor: {getCurrencySymbol(group.currency)} {group.price || '0.00'}</p>
                        
                        {displayQrCode && (
                            <div className="qrcode-wrapper">
                                <img src={displayQrCode} className="qrcode-img" alt="QR Code PIX" />
                            </div>
                        )}

                        <p className="text-xs text-gray-300 mb-1 mt-2">Copia e Cola:</p>
                        
                        {/* TEXTAREA DO CÓDIGO PIX */}
                        <textarea 
                            ref={pixTextAreaRef}
                            className="pix-textarea"
                            readOnly
                            value={pixCode || "Erro: Código não disponível."}
                            onClick={(e) => e.currentTarget.select()}
                        />
                        
                        {/* BOTÃO COPIAR */}
                        <button 
                            onClick={copyPixCode} 
                            className="w-full py-3 mb-4 font-semibold bg-[#00c2ff] text-[#0a0c10] rounded-lg hover:bg-white transition-colors border-none cursor-pointer flex items-center justify-center"
                            style={{ backgroundColor: isCopied ? '#10b981' : '' }}
                            disabled={!pixCode}
                        >
                            {isCopied ? (
                                <><i className="fa-solid fa-check mr-2"></i> Copiado!</>
                            ) : (
                                <><i className="fa-solid fa-copy mr-2"></i> Copiar Código Pix</>
                            )}
                        </button>
                        
                        <div className="flex flex-col items-center justify-center gap-2 text-xs text-gray-500">
                            <div className="flex items-center gap-2 animate-pulse">
                                <i className="fa-solid fa-spinner fa-spin"></i> Aguardando pagamento...
                            </div>
                            <button 
                                className="check-btn" 
                                onClick={() => checkStatusOnce(transactionId, group.creatorEmail || '')}
                                disabled={isChecking}
                            >
                                {isChecking ? 'Verificando...' : 'Já Paguei / Verificar'}
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    </div>
  );
};
