
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';
import { syncPayService } from '../services/syncPayService';

export const FinancialPanel: React.FC = () => {
  const navigate = useNavigate();
  const [selectedFilter, setSelectedFilter] = useState('Disponível');
  const [isConnected, setIsConnected] = useState(false);
  const [revenue, setRevenue] = useState(0); // Valor exibido (Saldo ou Faturamento)
  const [walletBalance, setWalletBalance] = useState(0); // Saldo real da carteira
  const [displayedRevenue, setDisplayedRevenue] = useState(0);
  const [loading, setLoading] = useState(true);
  const [allTransactions, setAllTransactions] = useState<any[]>([]);

  // Notification Interval State (0 = Disabled)
  const [notificationInterval, setNotificationInterval] = useState<number>(0);

  // Withdrawal State
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isProcessingWithdrawal, setIsProcessingWithdrawal] = useState(false);
  const [pixKeyType, setPixKeyType] = useState('cpf');
  const [pixKey, setPixKey] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  
  // Taxa Dinâmica (carregada do backend)
  const [withdrawalFee, setWithdrawalFee] = useState(5.00);

  const filters = ['Disponível', 'Hoje', 'Ontem', '7d', '30d', '180d'];

  // Load Data
  useEffect(() => {
      const loadData = async () => {
          const user = authService.getCurrentUser();
          if (user) {
              // Load Notification Preference
              const savedInterval = localStorage.getItem('fin_notification_interval');
              if (savedInterval) {
                  setNotificationInterval(parseInt(savedInterval));
              }

              // Check connection status
              setIsConnected(!!user.paymentConfig?.isConnected);
              
              // Carregar taxas atuais do servidor
              try {
                  const fees = await syncPayService.getFees();
                  setWithdrawalFee(fees.withdrawal_fee);
              } catch (e) {
                  console.warn("Não foi possível carregar taxas dinâmicas, usando padrão.", e);
              }
              
              if (user.paymentConfig?.isConnected) {
                  try {
                      // 1. Buscar Saldo Real (Disponível)
                      const balance = await syncPayService.getBalance(user.email);
                      setWalletBalance(balance);

                      // 2. Buscar Histórico (Para faturamento)
                      const transactions = await syncPayService.getTransactions(user.email);
                      setAllTransactions(transactions);
                  } catch (e) {
                      console.error("Erro ao buscar dados financeiros", e);
                  }
              }
          }
          setLoading(false);
      };
      loadData();
  }, []);

  // Filter Logic and Calculation
  useEffect(() => {
      calculateRevenue();
  }, [selectedFilter, allTransactions, walletBalance]);

  // Animation Effect
  useEffect(() => {
      let start = displayedRevenue;
      const end = revenue;
      if (start === end) return;

      const duration = 1000;
      const startTime = performance.now();

      const animate = (currentTime: number) => {
          const elapsed = currentTime - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          // Ease out quartic
          const ease = 1 - Math.pow(1 - progress, 4);
          
          const currentVal = start + (end - start) * ease;
          setDisplayedRevenue(currentVal);

          if (progress < 1) {
              requestAnimationFrame(animate);
          }
      };

      requestAnimationFrame(animate);
  }, [revenue]);

  const calculateRevenue = () => {
      // Se o filtro for "Disponível", mostramos o saldo da carteira
      if (selectedFilter === 'Disponível') {
          setRevenue(walletBalance);
          return;
      }

      // Lógica de Faturamento (Histórico)
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
      const oneDay = 24 * 60 * 60 * 1000;

      const filtered = allTransactions.filter(tx => {
          // 1. Filter by Status (Only approved/paid)
          const status = (tx.status || '').toLowerCase();
          const isPaid = ['paid', 'completed', 'approved', 'settled'].includes(status);
          if (!isPaid) return false;

          // 2. Filter by Date
          // Support both 'created_at' and 'createdAt'
          const dateStr = tx.created_at || tx.createdAt || tx.date_created;
          const txDate = new Date(dateStr).getTime();
          
          if (isNaN(txDate)) return false;

          switch(selectedFilter) {
              case 'Hoje': 
                  return txDate >= startOfDay;
              case 'Ontem': 
                  return txDate >= (startOfDay - oneDay) && txDate < startOfDay;
              case '7d': 
                  return txDate >= (now.getTime() - (7 * oneDay));
              case '30d': 
                  return txDate >= (now.getTime() - (30 * oneDay));
              case '180d': 
                  return txDate >= (now.getTime() - (180 * oneDay));
              default: 
                  return true;
          }
      });

      // 3. Sum Amounts
      const total = filtered.reduce((sum, tx) => sum + parseFloat(tx.amount || 0), 0);
      setRevenue(total);
  };

  const refreshData = async () => {
      setLoading(true);
      const user = authService.getCurrentUser();
      if (user && user.paymentConfig?.isConnected) {
          try {
              // Refresh Balance
              const balance = await syncPayService.getBalance(user.email);
              setWalletBalance(balance);

              // Refresh Transactions
              const transactions = await syncPayService.getTransactions(user.email);
              setAllTransactions(transactions);
              
              // Refresh fees too
              const fees = await syncPayService.getFees();
              setWithdrawalFee(fees.withdrawal_fee);
          } catch (e) {
              console.error("Erro ao recarregar", e);
          }
      }
      setLoading(false);
  };

  const handleIntervalChange = (value: number) => {
      setNotificationInterval(value);
      localStorage.setItem('fin_notification_interval', value.toString());
  };

  const handleRequestWithdrawal = async (e: React.FormEvent) => {
      e.preventDefault();
      
      const user = authService.getCurrentUser();
      if (!user) return;

      // Simple validation
      if (!pixKey) {
          alert("Insira uma chave Pix válida.");
          return;
      }
      const amount = parseFloat(withdrawAmount);
      
      // Refresh fee just in case before validation
      try {
          const fees = await syncPayService.getFees();
          setWithdrawalFee(fees.withdrawal_fee); // Update UI state
          
          if (isNaN(amount) || amount <= fees.withdrawal_fee) {
              alert(`O valor do saque deve ser maior que a taxa atual de R$ ${fees.withdrawal_fee.toFixed(2)}.`);
              return;
          }

          setIsProcessingWithdrawal(true);

          // CHAMADA REAL AO SERVIÇO
          await syncPayService.requestWithdrawal(user, amount, pixKey, pixKeyType);
          
          const netAmount = (amount - fees.withdrawal_fee).toFixed(2);
          alert(`✅ Saque solicitado com sucesso!\n\nValor Debitado: R$ ${amount.toFixed(2)}\nTaxa: R$ ${fees.withdrawal_fee.toFixed(2)}\nValor Líquido: R$ ${netAmount}`);
          
          setIsWithdrawModalOpen(false);
          setWithdrawAmount('');
          setPixKey('');
          
          // Refresh data to show transaction
          refreshData();

      } catch (err: any) {
          alert(`❌ Erro ao solicitar saque: ${err.message}`);
      } finally {
          setIsProcessingWithdrawal(false);
      }
  };

  // Calcular valor líquido para exibição
  const calcNetAmount = () => {
      const val = parseFloat(withdrawAmount);
      if (isNaN(val)) return 0;
      return Math.max(0, val - withdrawalFee);
  };

  return (
    <div className="h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-y-auto overflow-x-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }

        header {
            display:flex; align-items:center; justify-content:space-between; padding:16px;
            background: #0c0f14; position:fixed; width:100%; z-index:10;
            border-bottom:1px solid rgba(255,255,255,0.1); top: 0; height: 65px;
        }
        header button {
            background:none; border:none; color:#fff; font-size:24px; cursor:pointer;
            transition:0.3s; padding-right: 15px;
        }
        header h1 { font-size:20px; font-weight:600; }
        
        main {
            padding-top: 80px; padding-bottom: 40px;
            width: 100%; max-width: 600px; margin: 0 auto; padding-left: 20px; padding-right: 20px;
        }

        .flux-card {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 20px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            position: relative;
        }

        .refresh-btn {
            position: absolute; top: 20px; right: 20px;
            background: rgba(0,194,255,0.1); color: #00c2ff;
            border: none; border-radius: 50%; width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: 0.3s;
        }
        .refresh-btn:hover { background: rgba(0,194,255,0.2); transform: rotate(180deg); }

        .balance-label {
            font-size: 14px; color: rgba(255,255,255,0.6); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px;
        }
        .balance-amount {
            font-size: 42px; font-weight: 800; color: #00c2ff; margin-bottom: 20px;
            text-shadow: 0 0 15px rgba(0, 194, 255, 0.3);
            display: flex; align-items: baseline; gap: 5px;
        }
        .balance-amount span { font-size: 20px; font-weight: 600; color: #fff; }

        .filter-label {
            font-size: 14px; color: rgba(255,255,255,0.7); margin-bottom: 10px;
        }
        .filter-container {
            display: flex; gap: 8px; overflow-x: auto; padding-bottom: 5px;
            scrollbar-width: none; -webkit-overflow-scrolling: touch;
        }
        .filter-container::-webkit-scrollbar { display: none; }
        
        .filter-chip {
            padding: 8px 16px;
            border-radius: 20px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            color: rgba(255,255,255,0.6);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            white-space: nowrap;
        }
        .filter-chip:hover {
            background: rgba(255,255,255,0.1);
            color: #fff;
        }
        .filter-chip.active {
            background: rgba(0, 194, 255, 0.15);
            border-color: #00c2ff;
            color: #00c2ff;
            box-shadow: 0 0 10px rgba(0, 194, 255, 0.1);
        }

        .section-header {
            font-size: 16px; color: #fff; margin-bottom: 15px; font-weight: 700;
            display: flex; align-items: center; gap: 8px;
        }
        .section-header i { color: #FFD700; }

        /* Notification Selectors */
        .notif-options {
            display: flex; flex-direction: column; gap: 8px;
        }
        .notif-option {
            display: flex; align-items: center; justify-content: space-between;
            padding: 14px; border-radius: 12px;
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.05);
            cursor: pointer; transition: 0.2s;
        }
        .notif-option.selected {
            background: rgba(0, 194, 255, 0.1);
            border-color: #00c2ff;
        }
        .notif-label { font-size: 14px; color: #ddd; }
        .check-circle {
            width: 20px; height: 20px; border-radius: 50%; border: 2px solid #555;
            display: flex; align-items: center; justify-content: center;
        }
        .notif-option.selected .check-circle {
            border-color: #00c2ff; background: #00c2ff;
        }
        .check-circle::after {
            content: '✓'; color: #000; font-size: 12px; font-weight: bold; display: none;
        }
        .notif-option.selected .check-circle::after { display: block; }

        .provider-title {
            font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 15px;
            display: flex; align-items: center; gap: 10px;
        }
        .provider-title i { color: #00c2ff; }
        
        .connect-btn {
            width: 100%;
            padding: 14px;
            background: #00c2ff;
            color: #0c0f14;
            font-size: 16px;
            font-weight: 700;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 4px 12px rgba(0, 194, 255, 0.3);
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .connect-btn:hover {
            background: #fff;
            box-shadow: 0 6px 20px rgba(0, 194, 255, 0.5);
        }

        .withdraw-btn {
            width: 100%;
            padding: 14px;
            background: #00ff82;
            color: #0c0f14;
            font-size: 16px;
            font-weight: 700;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 4px 12px rgba(0, 255, 130, 0.3);
            display: flex; align-items: center; justify-content: center; gap: 8px;
            margin-top: 15px;
        }
        .withdraw-btn:hover {
            background: #ccffdd;
            box-shadow: 0 6px 20px rgba(0, 255, 130, 0.5);
        }

        .status-indicator {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 10px; border-radius: 20px;
            background: rgba(255, 77, 77, 0.1); color: #ff4d4d;
            font-size: 12px; font-weight: 600; margin-bottom: 15px;
        }
        .status-indicator.connected {
            background: rgba(0, 255, 130, 0.1); color: #00ff82;
        }
        .dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
        
        .info-text {
            font-size: 12px; color: #777; text-align: center; margin-top: 20px;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.8); z-index: 50;
            display: flex; align-items: center; justify-content: center;
            backdrop-filter: blur(5px);
        }
        .modal-content {
            background: #1a1e26; width: 90%; max-width: 380px; border-radius: 16px;
            padding: 20px; border: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        .modal-title { font-size: 18px; font-weight: 700; color: #00ff82; margin-bottom: 15px; text-align: center; }
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; font-size: 13px; color: #aaa; margin-bottom: 5px; }
        .input-group input, .input-group select {
            width: 100%; background: #0c0f14; border: 1px solid #333;
            border-radius: 8px; color: #fff; padding: 10px; outline: none;
        }
        .input-group input:focus { border-color: #00ff82; }
        
        .calc-row {
            display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 5px;
            padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .calc-row.total { border-top: 1px solid rgba(255,255,255,0.1); border-bottom: none; padding-top: 10px; font-weight: 700; color: #00ff82; font-size: 15px; }
        .fee-text { color: #ff4d4d; }

        .cancel-btn {
            width: 100%; padding: 10px; background: transparent; color: #aaa;
            border: 1px solid #333; border-radius: 8px; cursor: pointer; margin-top: 10px;
        }
      `}</style>

      <header>
        <button onClick={() => navigate('/settings')} aria-label="Voltar">
            <i className="fa-solid fa-arrow-left"></i>
        </button>
        <h1>Painel Financeiro</h1>
        <div style={{width: '24px'}}></div>
      </header>

      <main>
        {/* REVENUE CARD */}
        <div className="flux-card">
            <button className="refresh-btn" onClick={refreshData} disabled={loading}>
                <i className={`fa-solid fa-rotate-right ${loading ? 'fa-spin' : ''}`}></i>
            </button>

            <div className="balance-label">
                <i className="fa-solid fa-wallet mr-2"></i> 
                {selectedFilter === 'Disponível' ? 'Saldo Disponível' : `Faturamento (${selectedFilter})`}
            </div>
            
            <div className="balance-amount">
                <span>R$</span> 
                {displayedRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>

            <div className="filter-label">Visualizar:</div>
            <div className="filter-container">
                {filters.map(filter => (
                    <button 
                        key={filter}
                        className={`filter-chip ${selectedFilter === filter ? 'active' : ''}`}
                        onClick={() => setSelectedFilter(filter)}
                    >
                        {filter}
                    </button>
                ))}
            </div>

            <button className="withdraw-btn" onClick={() => setIsWithdrawModalOpen(true)}>
                <i className="fa-solid fa-money-bill-transfer"></i> Solicitar Saque
            </button>
        </div>

        {/* PROVIDER CONNECTION CARD */}
        <div className="flux-card">
            <div className="provider-title">
                <i className="fa-solid fa-plug"></i> Conexão com Provedor
            </div>
            
            <div className={`status-indicator ${isConnected ? 'connected' : ''}`}>
                <div className="dot"></div>
                {isConnected ? 'SyncPay Conectado' : 'Desconectado'}
            </div>

            <button className="connect-btn" onClick={() => navigate('/financial/providers')}>
                {isConnected ? 'Gerenciar Conexão' : 'Conectar SyncPay'}
            </button>
        </div>

        {/* NOTIFICATION INTERVAL SETTINGS */}
        <div className="flux-card">
            <div className="section-header">
                <i className="fa-solid fa-bell"></i> Alertas de Faturamento
            </div>
            <p style={{fontSize:'13px', color:'#aaa', marginBottom:'15px'}}>
                Receba uma notificação push consistente a cada intervalo acumulado.
            </p>
            
            <div className="notif-options">
                <div 
                    className={`notif-option ${notificationInterval === 0 ? 'selected' : ''}`}
                    onClick={() => handleIntervalChange(0)}
                >
                    <span className="notif-label">Desativado</span>
                    <div className="check-circle"></div>
                </div>

                <div 
                    className={`notif-option ${notificationInterval === 100 ? 'selected' : ''}`}
                    onClick={() => handleIntervalChange(100)}
                >
                    <span className="notif-label">A cada R$ 100,00</span>
                    <div className="check-circle"></div>
                </div>

                <div 
                    className={`notif-option ${notificationInterval === 1000 ? 'selected' : ''}`}
                    onClick={() => handleIntervalChange(1000)}
                >
                    <span className="notif-label">A cada R$ 1.000,00</span>
                    <div className="check-circle"></div>
                </div>

                <div 
                    className={`notif-option ${notificationInterval === 10000 ? 'selected' : ''}`}
                    onClick={() => handleIntervalChange(10000)}
                >
                    <span className="notif-label">A cada R$ 10.000,00</span>
                    <div className="check-circle"></div>
                </div>
            </div>
        </div>
        
        <p className="info-text">
            * O saldo disponível para saque é calculado com base nas transações aprovadas menos as taxas da plataforma. O processamento do saque pode levar até 1 dia útil.
        </p>
      </main>

      {/* MODAL DE SAQUE */}
      {isWithdrawModalOpen && (
          <div className="modal-overlay" onClick={() => !isProcessingWithdrawal && setIsWithdrawModalOpen(false)}>
              <div className="modal-content" onClick={e => e.stopPropagation()}>
                  <h3 className="modal-title">Solicitar Saque</h3>
                  
                  <form onSubmit={handleRequestWithdrawal}>
                      <div className="bg-[#1e2531] p-3 rounded-lg mb-4 border border-[#00c2ff]/30">
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                              <i className="fa-solid fa-wallet text-[#00c2ff]"></i>
                              <span>Origem: Sua Carteira SyncPay</span>
                          </div>
                      </div>

                      <div className="input-group">
                          <label>Valor a Debitar do Saldo (R$)</label>
                          <input 
                              type="number" 
                              placeholder="0.00" 
                              step="0.01" 
                              value={withdrawAmount}
                              onChange={e => setWithdrawAmount(e.target.value)}
                              required
                              disabled={isProcessingWithdrawal}
                          />
                      </div>

                      {/* Resumo de Valores */}
                      <div style={{background:'rgba(255,255,255,0.05)', borderRadius:'8px', padding:'10px', marginBottom:'15px'}}>
                          <div className="calc-row">
                              <span>Valor Solicitado:</span>
                              <span>R$ {parseFloat(withdrawAmount || '0').toFixed(2)}</span>
                          </div>
                          <div className="calc-row fee-text">
                              <span>Taxa de Saque:</span>
                              <span>- R$ {withdrawalFee.toFixed(2)}</span>
                          </div>
                          <div className="calc-row total">
                              <span>Valor Líquido a Receber:</span>
                              <span>R$ {calcNetAmount().toFixed(2)}</span>
                          </div>
                      </div>

                      <div className="input-group">
                          <label>Tipo de Chave Pix</label>
                          <select 
                            value={pixKeyType} 
                            onChange={e => setPixKeyType(e.target.value)}
                            disabled={isProcessingWithdrawal}
                          >
                              <option value="cpf">CPF/CNPJ</option>
                              <option value="email">E-mail</option>
                              <option value="phone">Telefone</option>
                              <option value="random">Chave Aleatória</option>
                          </select>
                      </div>

                      <div className="input-group">
                          <label>Chave Pix</label>
                          <input 
                              type="text" 
                              placeholder="Digite sua chave" 
                              value={pixKey}
                              onChange={e => setPixKey(e.target.value)}
                              required
                              disabled={isProcessingWithdrawal}
                          />
                      </div>

                      <button type="submit" className="withdraw-btn" disabled={isProcessingWithdrawal || parseFloat(withdrawAmount) <= withdrawalFee}>
                          {isProcessingWithdrawal ? <i className="fa-solid fa-circle-notch fa-spin"></i> : 'Confirmar Saque'}
                      </button>
                      <button type="button" className="cancel-btn" onClick={() => setIsWithdrawModalOpen(false)} disabled={isProcessingWithdrawal}>
                          Cancelar
                      </button>
                  </form>
              </div>
          </div>
      )}

    </div>
  );
};
