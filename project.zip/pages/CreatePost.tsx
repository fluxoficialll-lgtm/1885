




import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { postService } from '../services/postService';
import { authService } from '../services/authService';
import { groupService } from '../services/groupService';
import { contentSafetyService } from '../services/contentSafetyService';
import { adService } from '../services/adService';
import { Post, Group } from '../types';

interface MediaPreview {
  file: File;
  url: string;
  type: 'image'; // Strictly image for Feed
}

const LOCATIONS: any = {
    "Brasil": {
        "Ceará": ["Fortaleza", "Eusébio", "Aquiraz", "Sobral"],
        "São Paulo": ["São Paulo", "Campinas", "Santos", "Guarulhos"],
        "Rio de Janeiro": ["Rio de Janeiro", "Niterói", "Cabo Frio"],
        "Minas Gerais": ["Belo Horizonte", "Uberlândia", "Ouro Preto"]
    },
    "Estados Unidos": {
        "California": ["Los Angeles", "San Francisco", "San Diego"],
        "New York": ["New York City", "Buffalo"],
        "Florida": ["Miami", "Orlando"]
    },
    "Portugal": {
        "Lisboa": ["Lisboa", "Sintra", "Cascais"],
        "Porto": ["Porto", "Vila Nova de Gaia"]
    }
};

export const CreatePost: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const locationState = location.state as { isAd?: boolean } | null;
  const isAd = locationState?.isAd || false;

  const [text, setText] = useState('');
  const [mediaFiles, setMediaFiles] = useState<MediaPreview[]>([]);
  const [isPublishDisabled, setIsPublishDisabled] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  // Ad Specific States
  const [adBudget, setAdBudget] = useState('');
  const [adLink, setAdLink] = useState('');

  // Sensitive Content State (Auto-detected only now)
  const [isAdultContent, setIsAdultContent] = useState(false);

  // Location State
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [targetCountry, setTargetCountry] = useState('');
  const [targetState, setTargetState] = useState('');
  const [targetCity, setTargetCity] = useState('');
  const [displayLocation, setDisplayLocation] = useState('Global (Brasil)');

  // Group Attachment State
  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false);
  const [myGroups, setMyGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  
  // Auto-Sales Algorithm State
  const [autoSalesEnabled, setAutoSalesEnabled] = useState(true);

  const user = authService.getCurrentUser();
  const username = user?.profile?.name ? `@${user.profile.name}` : "@usuario";
  const avatarUrl = user?.profile?.photoUrl;

  useEffect(() => {
    const textLength = text.trim().length;
    const hasMedia = mediaFiles.length > 0;
    // If Ad, require budget
    const adValid = isAd ? (adBudget && parseFloat(adBudget) >= 10) : true;
    
    // Logic: Requires content OR a selected group
    // If selected group is VIP and inactive, block publish
    let groupValid = true;
    if (selectedGroup && selectedGroup.status === 'inactive') {
        groupValid = false;
    }

    setIsPublishDisabled(!(textLength > 0 || hasMedia || (selectedGroup && groupValid)) || !adValid || isProcessing);
  }, [text, mediaFiles, isProcessing, adBudget, isAd, selectedGroup]);

  // Load User Groups
  useEffect(() => {
      const email = authService.getCurrentUserEmail();
      if(email) {
          const allGroups = groupService.getGroupsSync();
          // Filter: Owned groups only.
          const ownedGroups = allGroups.filter(g => g.creatorEmail === email);
          setMyGroups(ownedGroups);
      }
  }, []);

  const handleMediaChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = event.target.files ? Array.from(event.target.files) : [];
    
    if (files.length > 0) {
      if (files.length + mediaFiles.length > 5) {
          alert("Você pode selecionar no máximo 5 arquivos no total.");
          return;
      }

      const newPreviews: MediaPreview[] = files.map(file => ({
          file: file,
          url: URL.createObjectURL(file),
          type: 'image'
      }));

      setMediaFiles(prev => [...prev, ...newPreviews]);
    }
  };

  const handleRemoveMedia = (index: number) => {
      setMediaFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Location Handlers
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setTargetCountry(e.target.value);
      setTargetState('');
      setTargetCity('');
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setTargetState(e.target.value);
      setTargetCity('');
  };

  const saveLocation = () => {
      let loc = 'Global (Brasil)';
      if (targetCity) loc = `${targetCity}, ${targetState}`; 
      else if (targetState) loc = `${targetState}, Brasil`;
      else if (targetCountry) loc = targetCountry === 'Brasil' ? 'Global (Brasil)' : targetCountry;

      setDisplayLocation(loc);
      setIsLocationModalOpen(false);
  };

  const clearLocation = () => {
      setTargetCountry('');
      setTargetState('');
      setTargetCity('');
      setDisplayLocation('Global (Brasil)');
      setIsLocationModalOpen(false);
  };

  const handleGroupSelect = (group: Group) => {
      if (group.status === 'inactive') {
          alert("Este grupo está inativo (sem provedor de pagamento). Conecte uma conta em 'Financeiro' para ativá-lo antes de postar.");
          return;
      }
      setSelectedGroup(group);
      setIsGroupModalOpen(false);
  };

  const handleRemoveGroup = () => {
      setSelectedGroup(null);
  };

  const handlePublishClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isPublishDisabled) return;
    
    // Bloqueia a UI imediatamente para feedback visual
    setIsProcessing(true);

    // Usa setTimeout para permitir que o React renderize o spinner de carregamento (UI Paint)
    // ANTES de iniciar a operação pesada de upload/base64. Isso evita o congelamento da tela.
    setTimeout(async () => {
        try {
            // 1. Upload (Robust Hybrid Logic inside Service with Circuit Breaker)
            const uploadPromises = mediaFiles.map(m => postService.uploadMedia(m.file));
            const uploadedRaw = await Promise.all(uploadPromises);
            const uploadedUrls = uploadedRaw.filter(u => u !== ""); // Filter failed uploads

            // 2. Content Safety Check (Local Mock - fast)
            const analysis = await contentSafetyService.analyzeContent(text, uploadedUrls.map(u => ({ url: u })));
            let finalAdultStatus = isAdultContent;

            if (analysis.isAdult) {
                finalAdultStatus = true;
            }

            const mainMediaUrl = uploadedUrls.length > 0 ? uploadedUrls[0] : undefined;
            // No longer detecting videos, assuming text or photo for Feed

            const newPost: Post = {
              id: Date.now().toString(),
              type: uploadedUrls.length > 0 ? 'photo' : 'text',
              username: username,
              avatar: avatarUrl,
              text: text,
              image: mainMediaUrl,
              images: uploadedUrls.length > 0 ? uploadedUrls : undefined,
              video: undefined, // Videos disabled for feed posts
              time: "Agora",
              timestamp: Date.now(),
              isPublic: true,
              isAdultContent: finalAdultStatus,
              isAd: isAd, // Important: Pass the isAd flag
              views: 0,
              likes: 0,
              comments: 0,
              liked: false,
              location: displayLocation,
              relatedGroupId: selectedGroup?.id
            };

            // 3. Save Post (Local First, Sync Later)
            await postService.addPost(newPost);
            
            if(isAd) alert(`Campanha Criada! Orçamento: R$ ${adBudget}`);

            // --- AUTO SALES ALGORITHM INJECTION ---
            if (selectedGroup?.isVip && autoSalesEnabled) {
                await adService.createCampaign({
                    id: Date.now().toString(),
                    name: `Auto-Boost: ${selectedGroup.name}`,
                    ownerEmail: user?.email || '',
                    scheduleType: 'continuous',
                    budget: 0, // FREE upfront
                    pricingModel: 'commission', // The key change
                    trafficObjective: 'conversions',
                    creative: {
                        text: text,
                        mediaUrl: mainMediaUrl,
                        mediaType: 'image'
                    },
                    campaignObjective: 'group_joins',
                    destinationType: 'group',
                    targetGroupId: selectedGroup.id,
                    optimizationGoal: 'group_joins',
                    placements: ['feed', 'reels', 'marketplace'], // Omni-channel
                    ctaButton: 'Entrar',
                    status: 'active',
                    timestamp: Date.now()
                });
                // Note: We don't alert here to make it seamless, but the algorithm picks it up.
            }
            
            // Limpa navegação
            navigate('/feed');
        } catch (error: any) {
            console.error("Erro ao publicar:", error?.message || JSON.stringify(error));
            alert("Erro ao publicar o post. Tente novamente.");
            // Don't navigate away on error, let user retry
        } finally {
            // Garante que o botão destrave se a navegação falhar
            setIsProcessing(false);
        }
    }, 50); // Pequeno delay para UI respirar
  };

  const countries = Object.keys(LOCATIONS);
  const states = targetCountry ? Object.keys(LOCATIONS[targetCountry] || {}) : [];
  const cities = (targetCountry && targetState) ? LOCATIONS[targetCountry][targetState] || [] : [];

  return (
    <div className="h-screen flex flex-col overflow-y-auto overflow-x-hidden font-['Inter']" style={{ background: 'radial-gradient(circle at 5% 5%, #0c0f14, #0a0c10)', color: '#fff' }}>
      <style>{`
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-font-smoothing: antialiased; }
        header.cp-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; background: #0c0f14; position: fixed; width: 100%; z-index: 50; border-bottom: 1px solid rgba(255, 255, 255, 0.1); top: 0; left: 0; }
        header.cp-header h1 { font-size: 18px; font-weight: 600; color: #00c2ff; }
        header.cp-header button.icon-btn { background: none; border: none; color: #00c2ff; font-size: 18px; cursor: pointer; padding: 8px; }
        #publishbtn { background: #00c2ff; color: #0c0f14; padding: 8px 16px; border-radius: 8px; font-weight: bold; font-size: 16px; border: none; cursor: pointer; min-width: 80px; display: flex; align-items: center; justify-content: center;}
        #publishbtn:disabled { background: rgba(0, 194, 255, 0.2); color: rgba(255, 255, 255, 0.5); cursor: not-allowed; }
        main.cp-main { flex-grow: 1; width: 100%; max-width: 600px; margin: 0 auto; padding: 100px 20px 40px 20px; }
        .post-creation-area { display: flex; gap: 15px; margin-bottom: 20px; background: rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 15px; }
        .post-creation-area .avatar { width: 48px; height: 48px; border-radius: 50%; border: 3px solid #00c2ff; object-fit: cover; flex-shrink: 0; }
        .post-creation-area .avatar-placeholder { width: 48px; height: 48px; border-radius: 50%; border: 3px solid #00c2ff; background: #1e2531; flex-shrink: 0; display: flex; align-items: center; justify-content: center; color: #00c2ff; font-size: 20px; }
        .content-container { flex-grow: 1; overflow: hidden; }
        .text-input-container { flex-grow: 1; padding-bottom: 10px; }
        #posttext { width: 100%; min-height: 100px; background: none; border: none; resize: vertical; color: #fff; font-size: 16px; line-height: 1.4; padding: 10px 0; outline: none; }
        .icon-attachment-bar { display: flex; gap: 15px; padding-top: 10px; border-top: 1px solid rgba(255, 255, 255, 0.1); }
        .icon-attachment-bar button, .icon-attachment-bar label { background: none; border: none; color: #00c2ff; font-size: 20px; cursor: pointer; padding: 5px; }
        .icon-attachment-bar input[type="file"] { display: none; }
        #mediapreviewcontainer { margin-top: 15px; border: 1px dashed rgba(0,194,255,0.3); border-radius: 8px; padding: 10px; background: rgba(0,0,0,0.2); }
        .preview-gallery { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 10px; }
        .media-wrapper { flex: 0 0 auto; height: 350px; min-width: 150px; position: relative; border-radius: 8px; overflow: hidden; border: 1px solid rgba(255,255,255,0.1); background: #000; display: flex; align-items: center; justify-content: center; }
        .media-preview-element { height: 100%; width: auto; max-width: 100%; object-fit: contain; }
        .video-badge { position: absolute; bottom: 5px; left: 5px; background: rgba(0,0,0,0.7); color: #fff; padding: 2px 6px; border-radius: 4px; font-size: 10px; }
        .remove-btn { position: absolute; top: 5px; right: 5px; background: rgba(0,0,0,0.6); color: #fff; border: none; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .options-container { display: flex; flex-direction: column; gap: 15px; }
        .option-item { background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; border: 1px solid transparent; }
        .option-item:hover { background: rgba(0, 194, 255, 0.15); border-color: #00c2ff; }
        .option-item span { font-size: 15px; color: #fff; }
        .option-item i { color: #00c2ff; }
        .server-selection { font-weight: bold; color: #00c2ff; margin-left: 10px; }
        
        /* Modals */
        .location-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 50; display: flex; align-items: center; justify-content: center; }
        .location-modal { background: #1a1e26; border: 1px solid #00c2ff; border-radius: 16px; padding: 20px; width: 90%; max-width: 350px; display: flex; flex-direction: column; max-height: 70vh; }
        .modal-title { font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 20px; text-align: center; }
        .select-group { margin-bottom: 15px; }
        .select-group label { display: block; font-size: 12px; color: #aaa; margin-bottom: 5px; }
        .select-group select { width: 100%; background: #0c0f14; border: 1px solid #333; color: #fff; padding: 10px; border-radius: 8px; outline: none; }
        .modal-actions { display: flex; gap: 10px; margin-top: 20px; }
        .modal-btn { flex: 1; padding: 10px; border-radius: 8px; border: none; font-weight: 700; cursor: pointer; }
        .save-loc-btn { background: #00c2ff; color: #000; }
        .clear-loc-btn { background: transparent; border: 1px solid #ff4d4d; color: #ff4d4d; }
        
        .ad-banner {
            background: linear-gradient(90deg, #FFD700, #B8860B);
            color: #000; padding: 10px; border-radius: 12px; margin-bottom: 20px;
            display: flex; align-items: center; gap: 10px; font-weight: 700;
        }
        .ad-input {
            width: 100%; padding: 12px; background: rgba(255,215,0,0.1);
            border: 1px solid #FFD700; border-radius: 8px; color: #fff; outline: none;
            margin-top: 5px;
        }

        .group-list { overflow-y: auto; flex: 1; padding-right: 5px; }
        .group-item {
            display: flex; align-items: center; padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer;
        }
        .group-item:hover { background: rgba(0,194,255,0.1); }
        .group-cover {
            width: 40px; height: 40px; border-radius: 50%; object-fit: cover; margin-right: 12px; background: #333; display: flex; align-items: center; justify-content: center;
        }
        .group-info { flex: 1; }
        .group-name { font-weight: 600; font-size: 14px; }
        .group-type { font-size: 11px; color: #aaa; text-transform: uppercase; }
        .vip-tag { color: #FFD700; }
        .selected-group-banner {
            background: rgba(0,194,255,0.1); border: 1px solid #00c2ff; border-radius: 8px;
            padding: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;
        }
        .selected-info { font-weight: 600; color: #fff; display: flex; align-items: center; gap: 8px; }
        .remove-group-btn { color: #ff4d4d; cursor: pointer; font-size: 14px; }

        /* Auto Sales Toggle */
        .auto-sales-card {
            background: linear-gradient(145deg, rgba(0, 255, 130, 0.05), rgba(0,0,0,0));
            border: 1px solid #00ff82; border-radius: 10px; padding: 15px; margin-bottom: 20px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .auto-sales-info h4 { color: #00ff82; font-size: 14px; font-weight: 700; margin-bottom: 4px; display: flex; align-items: center; gap: 6px; }
        .auto-sales-info p { color: #aaa; font-size: 11px; max-width: 220px; line-height: 1.3; }
        
        /* Switch */
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #333; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #00ff82; }
        input:checked + .slider:before { transform: translateX(20px); }
      `}</style>

      <header className="cp-header">
        <button className="icon-btn" onClick={() => navigate('/feed')} aria-label="fechar" role="button">
          <i className="fa-solid fa-xmark"></i>
        </button>
        <h1>{isAd ? 'Nova Campanha' : 'Nova Postagem'}</h1>
        <button id="publishbtn" disabled={isPublishDisabled} onClick={handlePublishClick}>
            {isProcessing ? <i className="fa-solid fa-circle-notch fa-spin"></i> : (isAd ? 'Pagar & Publicar' : 'Publicar')}
        </button>
      </header>

      <main className="cp-main">
        {isAd && (
            <div className="ad-banner">
                <i className="fa-solid fa-bullhorn"></i> Modo Anúncio (Feed)
            </div>
        )}

        <form id="postform" onSubmit={(e) => e.preventDefault()}> 
          <div className="post-creation-area">
            {avatarUrl ? (
                <img src={avatarUrl} className="avatar" id="useravatar" alt="avatar do usuário" />
            ) : (
                <div className="avatar-placeholder">
                    <i className="fa-solid fa-user"></i>
                </div>
            )}
            
            <div className="content-container">
              <div className="text-input-container">
                <textarea 
                  id="posttext" 
                  placeholder="o que você está pensando? diga ao seu servidor..." 
                  maxLength={1000}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                ></textarea>
              </div>

              {selectedGroup && (
                  <div className="selected-group-banner">
                      <div className="selected-info">
                          <i className={`fa-solid ${selectedGroup.isVip ? 'fa-crown' : (selectedGroup.isPrivate ? 'fa-lock' : 'fa-globe')}`} style={{color: selectedGroup.isVip ? '#FFD700' : '#00c2ff'}}></i>
                          {selectedGroup.name}
                      </div>
                      <div className="remove-group-btn" onClick={handleRemoveGroup}>
                          <i className="fa-solid fa-xmark"></i>
                      </div>
                  </div>
              )}

              <div className="icon-attachment-bar">
                <button type="button" onClick={() => alert('Ação: abrir a câmera para tirar foto.')} aria-label="abrir câmera">
                  <i className="fa-solid fa-camera"></i>
                </button>
                
                <label htmlFor="mediainput" aria-label="adicionar foto">
                  <i className="fa-solid fa-image"></i>
                  <input 
                    type="file" 
                    id="mediainput" 
                    accept="image/*" 
                    multiple 
                    onChange={handleMediaChange} 
                  />
                </label>

                <button type="button" onClick={() => navigate('/create-poll')} aria-label="criar enquete">
                  <i className="fa-solid fa-square-poll-vertical"></i>
                </button>
              </div>

              {mediaFiles.length > 0 && (
                <div id="mediapreviewcontainer">
                  <div className="preview-gallery">
                    {mediaFiles.map((item, index) => (
                      <div key={index} className="media-wrapper">
                        <img src={item.url} alt={`preview ${index}`} className="media-preview-element" />
                        <button className="remove-btn" onClick={() => handleRemoveMedia(index)}>
                            <i className="fa-solid fa-xmark"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* AD SPECIFIC FIELDS */}
          {isAd && (
              <div className="options-container" style={{marginBottom: '20px'}}>
                  <div className="option-item" style={{flexDirection: 'column', alignItems: 'flex-start'}}>
                      <span style={{color: '#FFD700'}}>Orçamento Total (R$)</span>
                      <input 
                        type="number" 
                        className="ad-input" 
                        placeholder="Mínimo R$ 10,00"
                        value={adBudget}
                        onChange={(e) => setAdBudget(e.target.value)}
                      />
                  </div>
                  <div className="option-item" style={{flexDirection: 'column', alignItems: 'flex-start'}}>
                      <span style={{color: '#FFD700'}}>Link de Ação (Botão)</span>
                      <input 
                        type="url" 
                        className="ad-input" 
                        placeholder="https://seusite.com"
                        value={adLink}
                        onChange={(e) => setAdLink(e.target.value)}
                      />
                  </div>
              </div>
          )}

          {/* AUTOMATIC VIP SALES TOGGLE */}
          {selectedGroup?.isVip && !isAd && (
              <div className="auto-sales-card">
                  <div className="auto-sales-info">
                      <h4><i className="fa-solid fa-bolt"></i> Algoritmo de Vendas (Grátis)</h4>
                      <p>Entregamos seu post automaticamente para compradores potenciais. Sem custo de anúncio.</p>
                  </div>
                  <label className="switch">
                      <input type="checkbox" checked={autoSalesEnabled} onChange={() => setAutoSalesEnabled(!autoSalesEnabled)} />
                      <span className="slider"></span>
                  </label>
              </div>
          )}

          <div className="options-container">
            <div className="option-item" role="button" onClick={() => setIsLocationModalOpen(true)}>
              <span>
                <i className="fa-solid fa-location-dot"></i> Alcance: 
                <span className="server-selection" id="currentaudience">{displayLocation}</span>
              </span>
              <i className="fa-solid fa-chevron-right"></i>
            </div>

            <div className="option-item" role="button" onClick={() => setIsGroupModalOpen(true)}>
                <span>
                    <i className="fa-solid fa-users-rectangle"></i> Anexar Grupo
                </span>
                <i className="fa-solid fa-chevron-right"></i>
            </div>
          </div>
        </form>
      </main>

      {/* Location Modal */}
      {isLocationModalOpen && (
          <div className="location-modal-overlay" onClick={() => setIsLocationModalOpen(false)}>
              <div className="location-modal" onClick={(e) => e.stopPropagation()}>
                  <div className="modal-title">Definir Alcance {isAd ? 'do Anúncio' : 'do Post'}</div>
                  
                  <div className="select-group">
                      <label>País</label>
                      <select value={targetCountry} onChange={handleCountryChange}>
                          <option value="">Todos / Global</option>
                          {countries.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                  </div>

                  {targetCountry && (
                      <div className="select-group">
                          <label>Estado</label>
                          <select value={targetState} onChange={handleStateChange}>
                              <option value="">Todos do País</option>
                              {states.map((s: string) => <option key={s} value={s}>{s}</option>)}
                          </select>
                      </div>
                  )}

                  {targetState && (
                      <div className="select-group">
                          <label>Cidade</label>
                          <select value={targetCity} onChange={(e) => setTargetCity(e.target.value)}>
                              <option value="">Todas do Estado</option>
                              {cities.map((c: string) => <option key={c} value={c}>{c}</option>)}
                          </select>
                      </div>
                  )}

                  <div className="modal-actions">
                      <button className="modal-btn clear-loc-btn" onClick={clearLocation}>Global</button>
                      <button className="modal-btn save-loc-btn" onClick={saveLocation}>Salvar</button>
                  </div>
              </div>
          </div>
      )}

      {/* Group Modal */}
      {isGroupModalOpen && (
          <div className="location-modal-overlay" onClick={() => setIsGroupModalOpen(false)}>
              <div className="location-modal" onClick={(e) => e.stopPropagation()}>
                  <div className="modal-title">Selecionar Grupo</div>
                  
                  <div className="group-list">
                      {myGroups.length > 0 ? myGroups.map(group => (
                          <div key={group.id} className="group-item" onClick={() => handleGroupSelect(group)}>
                              {group.coverImage ? (
                                  <img src={group.coverImage} className="group-cover" alt="Group" />
                              ) : (
                                  <div className="group-cover">
                                      <i className={`fa-solid ${group.isVip ? 'fa-crown' : 'fa-users'}`}></i>
                                  </div>
                              )}
                              <div className="group-info">
                                  <div className="group-name">{group.name}</div>
                                  <div className={`group-type ${group.isVip ? 'vip-tag' : ''}`}>
                                      {group.isVip ? 'VIP' : (group.isPrivate ? 'Privado' : 'Público')}
                                  </div>
                              </div>
                              <i className="fa-solid fa-chevron-right text-gray-500"></i>
                          </div>
                      )) : (
                          <div style={{textAlign:'center', color:'#777', padding:'20px'}}>
                              Nenhum grupo ativo disponível.
                          </div>
                      )}
                  </div>

                  <div className="modal-actions">
                      <button className="modal-btn clear-loc-btn" onClick={() => setIsGroupModalOpen(false)}>Fechar</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};