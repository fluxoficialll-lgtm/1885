


import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { authService } from '../services/authService';
import { reelsService } from '../services/reelsService';
import { groupService } from '../services/groupService';
import { contentSafetyService } from '../services/contentSafetyService';
import { adService } from '../services/adService';
import { Post, Group } from '../types';

// Mock Data for Locations
const LOCATIONS: any = {
    "Brasil": {
        "Ceará": ["Fortaleza", "Eusébio", "Aquiraz", "Sobral"],
        "São Paulo": ["São Paulo", "Campinas", "Santos", "Guarulhos"],
        "Rio de Janeiro": ["Rio de Janeiro", "Niterói", "Cabo Frio"],
        "Minas Gerais": ["Belo Horizonte", "Uberlândia", "Ouro Preto"]
    },
    "Estados Unidos": {
        "California": ["Los Angeles", "San Francisco", "San Diego"],
        "New York": ["New York City", "Buffalo"],
        "Florida": ["Miami", "Orlando"]
    },
    "Portugal": {
        "Lisboa": ["Lisboa", "Sintra", "Cascais"],
        "Porto": ["Porto", "Vila Nova de Gaia"]
    }
};

export const CreateReel: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const locationState = location.state as { isAd?: boolean } | null;
  const isAd = locationState?.isAd || false;

  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [title, setTitle] = useState(''); 
  const [isPublishDisabled, setIsPublishDisabled] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  // Ad Specific States
  const [adBudget, setAdBudget] = useState('');
  const [adLink, setAdLink] = useState('');

  // Sensitive Content (Auto only now)
  const [isAdultContent, setIsAdultContent] = useState(false);

  // Location State
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [targetCountry, setTargetCountry] = useState('');
  const [targetState, setTargetState] = useState('');
  const [targetCity, setTargetCity] = useState('');
  const [displayLocation, setDisplayLocation] = useState('Global (Brasil)');

  // Group Attachment State
  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false);
  const [myGroups, setMyGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);

  // Auto-Sales Algorithm State
  const [autoSalesEnabled, setAutoSalesEnabled] = useState(true);

  useEffect(() => {
    const hasVideo = !!videoFile;
    const hasCaption = caption.trim().length > 0;
    const adValid = isAd ? (adBudget && parseFloat(adBudget) >= 10) : true;

    // Logic: Requires video AND (caption OR group)
    // If selected group is VIP and inactive, block publish
    let groupValid = true;
    if (selectedGroup && selectedGroup.status === 'inactive') {
        groupValid = false;
    }

    setIsPublishDisabled(!(hasVideo && (hasCaption || (selectedGroup && groupValid))) || !adValid || isProcessing);
  }, [videoFile, caption, isProcessing, adBudget, isAd, selectedGroup]);

  // Load User Groups
  useEffect(() => {
      const email = authService.getCurrentUserEmail();
      if(email) {
          const allGroups = groupService.getGroupsSync();
          // Filter: Owned groups only.
          const ownedGroups = allGroups.filter(g => g.creatorEmail === email);
          setMyGroups(ownedGroups);
      }
  }, []);

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
      setVideoPreviewUrl(URL.createObjectURL(file));
    } else {
      setVideoFile(null);
      setVideoPreviewUrl(null);
    }
  };

  // Location Handlers
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setTargetCountry(e.target.value);
      setTargetState('');
      setTargetCity('');
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setTargetState(e.target.value);
      setTargetCity('');
  };

  const saveLocation = () => {
      let loc = 'Global (Brasil)';
      if (targetCity) loc = `${targetCity}, ${targetState}`; 
      else if (targetState) loc = `${targetState}, Brasil`;
      else if (targetCountry) loc = targetCountry === 'Brasil' ? 'Global (Brasil)' : targetCountry;

      setDisplayLocation(loc);
      setIsLocationModalOpen(false);
  };

  const clearLocation = () => {
      setTargetCountry('');
      setTargetState('');
      setTargetCity('');
      setDisplayLocation('Global (Brasil)');
      setIsLocationModalOpen(false);
  };

  const handleGroupSelect = (group: Group) => {
      if (group.status === 'inactive') {
          alert("Este grupo está inativo (sem provedor de pagamento). Conecte uma conta em 'Financeiro' para ativá-lo antes de postar.");
          return;
      }
      setSelectedGroup(group);
      setIsGroupModalOpen(false);
  };

  const handleRemoveGroup = () => {
      setSelectedGroup(null);
  };

  const handlePublish = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isPublishDisabled || !videoFile) return;

    // Atualiza estado para mostrar spinner
    setIsProcessing(true);

    // Envolve em setTimeout para garantir que a UI atualize ANTES da thread principal
    // ser ocupada pela conversão de vídeo ou upload.
    setTimeout(async () => {
        try {
            // 1. Upload Video (Serviço com fallback robusto)
            const uploadedVideoUrl = await reelsService.uploadVideo(videoFile);

            // 2. Auto Detection
            const textToCheck = `${title} ${caption}`;
            const analysis = await contentSafetyService.analyzeContent(textToCheck, [{url: uploadedVideoUrl, type: 'video'}]);
            let finalAdultStatus = isAdultContent;

            if (analysis.isAdult) {
                finalAdultStatus = true;
            }

            const currentUser = authService.getCurrentUser();
            const username = currentUser?.profile?.name ? `@${currentUser.profile.name}` : '@usuario';
            const avatar = currentUser?.profile?.photoUrl;

            const newReel: Post = {
                id: Date.now().toString(),
                type: 'video',
                username: username,
                avatar: avatar,
                title: title, 
                text: caption, 
                video: uploadedVideoUrl,
                time: 'Agora',
                timestamp: Date.now(),
                isPublic: true,
                isAdultContent: finalAdultStatus,
                views: 0,
                likes: 0,
                comments: 0,
                liked: false,
                location: displayLocation,
                relatedGroupId: selectedGroup?.id
            };

            await reelsService.addReel(newReel);
            
            if(isAd) alert(`Reel Patrocinado Criado! Orçamento: R$ ${adBudget}`);

            // --- AUTO SALES ALGORITHM INJECTION ---
            if (selectedGroup?.isVip && autoSalesEnabled && !isAd) {
                await adService.createCampaign({
                    id: Date.now().toString(),
                    name: `Auto-Boost (Reel): ${selectedGroup.name}`,
                    ownerEmail: currentUser?.email || '',
                    scheduleType: 'continuous',
                    budget: 0, // FREE upfront
                    pricingModel: 'commission',
                    trafficObjective: 'conversions',
                    creative: {
                        text: caption || title || "Confira este Reel exclusivo!",
                        mediaUrl: uploadedVideoUrl, // Use the uploaded video for the ad creative too
                        mediaType: 'video'
                    },
                    campaignObjective: 'group_joins',
                    destinationType: 'group',
                    targetGroupId: selectedGroup.id,
                    optimizationGoal: 'group_joins',
                    placements: ['feed', 'reels', 'marketplace'], // Boost everywhere
                    ctaButton: 'Entrar',
                    status: 'active',
                    timestamp: Date.now()
                });
            }

            navigate('/reels'); 
        } catch (error: any) {
            console.error("Publish error:", error?.message || JSON.stringify(error));
            // Navegar mesmo com erro para não travar a UI em loops infinitos
            navigate('/reels');
        } finally {
            // Sempre libera o botão
            setIsProcessing(false);
        }
    }, 50); // Delay curto para UX
  };

  // Derived lists for dropdowns
  const countries = Object.keys(LOCATIONS);
  const states = targetCountry ? Object.keys(LOCATIONS[targetCountry] || {}) : [];
  const cities = (targetCountry && targetState) ? LOCATIONS[targetCountry][targetState] || [] : [];

  return (
    <div className="h-screen flex flex-col overflow-y-auto overflow-x-hidden font-['Inter']" style={{ background: 'radial-gradient(circle at 5% 5%, #0c0f14, #0a0c10)', color: '#fff' }}>
      <style>{`
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-font-smoothing: antialiased; }
        header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; background: #0c0f14; position: fixed; width: 100%; z-index: 50; border-bottom: 1px solid rgba(255, 255, 255, 0.1); top: 0; }
        header h1 { font-size: 18px; font-weight: 600; color: #00c2ff; }
        header button { background: none; border: none; color: #00c2ff; font-size: 18px; cursor: pointer; padding: 8px; }
        #publishbtn { background: #00c2ff; color: #0c0f14; padding: 8px 16px; border-radius: 8px; font-weight: bold; font-size: 16px; border: none; cursor: pointer; min-width: 80px; display: flex; align-items: center; justify-content: center; }
        #publishbtn:disabled { background: rgba(0, 194, 255, 0.2); color: rgba(255, 255, 255, 0.5); cursor: not-allowed; }
        main { flex-grow: 1; width: 100%; max-width: 600px; margin: 0 auto; padding: 100px 20px 40px 20px; }
        .reel-creation-area { display: flex; flex-direction: column; gap: 15px; margin-bottom: 20px; background: rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 15px; }
        .video-input-container { position: relative; width: 100%; padding-bottom: 177.77%; background: #1a1a1a; border-radius: 8px; overflow: hidden; display: flex; align-items: center; justify-content: center; cursor: pointer; border: 2px dashed rgba(0, 194, 255, 0.5); }
        .video-input-container:hover { border-color: #00c2ff; background: #2a2a2a; }
        .video-placeholder-content { position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; color: rgba(255, 255, 255, 0.6); font-size: 16px; }
        .video-placeholder-content i { font-size: 40px; color: #00c2ff; }
        #reelvideo { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; background-color: #000; }
        #videoinput { display: none; }
        .reel-details { display: flex; flex-direction: column; gap: 10px; }
        .reel-details textarea { width: 100%; min-height: 80px; background: none; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 8px; color: #fff; font-size: 15px; padding: 10px; resize: vertical; outline: none; }
        .reel-details textarea:focus { border-color: #00c2ff; }
        .reel-details input[type="text"] { width: 100%; background: none; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 8px; color: #fff; font-size: 14px; padding: 10px; outline: none; font-weight: 600; }
        .reel-details input[type="text"]:focus { border-color: #00c2ff; }
        .options-container { display: flex; flex-direction: column; gap: 15px; }
        .option-item { background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; }
        .option-item span { font-size: 15px; color: #fff; }
        .option-item i { color: #00c2ff; }
        .server-selection { font-weight: bold; color: #00c2ff; margin-left: 10px; }
        .location-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 100; display: flex; align-items: center; justify-content: center; }
        .location-modal { background: #1a1e26; border: 1px solid #00c2ff; border-radius: 16px; padding: 20px; width: 90%; max-width: 350px; }
        .modal-title { font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 20px; text-align: center; }
        .select-group { margin-bottom: 15px; }
        .select-group label { display: block; font-size: 12px; color: #aaa; margin-bottom: 5px; }
        .select-group select { width: 100%; background: #0c0f14; border: 1px solid #333; color: #fff; padding: 10px; border-radius: 8px; outline: none; }
        .modal-actions { display: flex; gap: 10px; margin-top: 20px; }
        .modal-btn { flex: 1; padding: 10px; border-radius: 8px; border: none; font-weight: 700; cursor: pointer; }
        .save-loc-btn { background: #00c2ff; color: #000; }
        .clear-loc-btn { background: transparent; border: 1px solid #ff4d4d; color: #ff4d4d; }

        .ad-banner {
            background: linear-gradient(90deg, #FFD700, #B8860B);
            color: #000; padding: 10px; border-radius: 12px; margin-bottom: 20px;
            display: flex; align-items: center; gap: 10px; font-weight: 700;
        }
        .ad-input {
            width: 100%; padding: 12px; background: rgba(255,215,0,0.1);
            border: 1px solid #FFD700; border-radius: 8px; color: #fff; outline: none;
            margin-top: 5px;
        }

        .group-list { overflow-y: auto; flex: 1; padding-right: 5px; max-height: 50vh; }
        .group-item {
            display: flex; align-items: center; padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer;
        }
        .group-item:hover { background: rgba(0,194,255,0.1); }
        .group-cover {
            width: 40px; height: 40px; border-radius: 50%; object-fit: cover; margin-right: 12px; background: #333; display: flex; align-items: center; justify-content: center;
        }
        .group-info { flex: 1; }
        .group-name { font-weight: 600; font-size: 14px; }
        .group-type { font-size: 11px; color: #aaa; text-transform: uppercase; }
        .vip-tag { color: #FFD700; }
        
        .selected-group-banner {
            background: rgba(0,194,255,0.1); border: 1px solid #00c2ff; border-radius: 8px;
            padding: 10px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;
        }
        .selected-info { font-weight: 600; color: #fff; display: flex; align-items: center; gap: 8px; }
        .remove-group-btn { color: #ff4d4d; cursor: pointer; font-size: 14px; }

        /* Auto Sales Toggle */
        .auto-sales-card {
            background: linear-gradient(145deg, rgba(0, 255, 130, 0.05), rgba(0,0,0,0));
            border: 1px solid #00ff82; border-radius: 10px; padding: 15px; margin-bottom: 20px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .auto-sales-info h4 { color: #00ff82; font-size: 14px; font-weight: 700; margin-bottom: 4px; display: flex; align-items: center; gap: 6px; }
        .auto-sales-info p { color: #aaa; font-size: 11px; max-width: 220px; line-height: 1.3; }
        
        /* Switch */
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #333; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #00ff82; }
        input:checked + .slider:before { transform: translateX(20px); }
      `}</style>

      <header>
        <button onClick={() => navigate('/create-post')} aria-label="fechar" role="button">
          <i className="fa-solid fa-xmark"></i>
        </button>
        <h1>{isAd ? 'Novo Reel Patrocinado' : 'Novo Reel'}</h1>
        <button id="publishbtn" disabled={isPublishDisabled} onClick={handlePublish}>
            {isProcessing ? <i className="fa-solid fa-circle-notch fa-spin"></i> : (isAd ? 'Pagar & Publicar' : 'Publicar')}
        </button>
      </header>

      <main>
        {isAd && (
            <div className="ad-banner">
                <i className="fa-solid fa-video"></i> Modo Anúncio (Reels)
            </div>
        )}

        <form id="reelform" onSubmit={(e) => e.preventDefault()}> 
          <div className="reel-creation-area">
            <label htmlFor="videoinput" className="video-input-container">
              {videoPreviewUrl ? (
                <video id="reelvideo" controls src={videoPreviewUrl} />
              ) : (
                <div className="video-placeholder-content" id="videoplaceholder">
                  <i className="fa-solid fa-video"></i>
                  <span>toque para adicionar vídeo</span>
                </div>
              )}
              <input type="file" id="videoinput" accept="video/*" onChange={handleVideoChange} />
            </label>
            
            <div className="reel-details">
              <textarea 
                id="reelcaption" 
                placeholder="adicione uma legenda ao seu reel..." 
                maxLength={2200}
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
              ></textarea>
              
              <input 
                type="text" 
                placeholder="título curto (opcional)" 
                maxLength={50} 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
          </div>

          {selectedGroup && (
              <div className="selected-group-banner">
                  <div className="selected-info">
                      <i className={`fa-solid ${selectedGroup.isVip ? 'fa-crown' : (selectedGroup.isPrivate ? 'fa-lock' : 'fa-globe')}`} style={{color: selectedGroup.isVip ? '#FFD700' : '#00c2ff'}}></i>
                      {selectedGroup.name}
                  </div>
                  <div className="remove-group-btn" onClick={handleRemoveGroup}>
                      <i className="fa-solid fa-xmark"></i>
                  </div>
              </div>
          )}

          {/* AD SPECIFIC FIELDS */}
          {isAd && (
              <div className="options-container" style={{marginBottom: '20px'}}>
                  <div className="option-item" style={{flexDirection: 'column', alignItems: 'flex-start'}}>
                      <span style={{color: '#FFD700'}}>Orçamento Total (R$)</span>
                      <input 
                        type="number" 
                        className="ad-input" 
                        placeholder="Mínimo R$ 10,00"
                        value={adBudget}
                        onChange={(e) => setAdBudget(e.target.value)}
                      />
                  </div>
                  <div className="option-item" style={{flexDirection: 'column', alignItems: 'flex-start'}}>
                      <span style={{color: '#FFD700'}}>Link de Ação (Botão)</span>
                      <input 
                        type="url" 
                        className="ad-input" 
                        placeholder="https://seusite.com"
                        value={adLink}
                        onChange={(e) => setAdLink(e.target.value)}
                      />
                  </div>
              </div>
          )}

          {/* AUTOMATIC VIP SALES TOGGLE */}
          {selectedGroup?.isVip && !isAd && (
              <div className="auto-sales-card">
                  <div className="auto-sales-info">
                      <h4><i className="fa-solid fa-bolt"></i> Algoritmo de Vendas (Grátis)</h4>
                      <p>Entregamos seu post automaticamente para compradores potenciais. Sem custo de anúncio.</p>
                  </div>
                  <label className="switch">
                      <input type="checkbox" checked={autoSalesEnabled} onChange={() => setAutoSalesEnabled(!autoSalesEnabled)} />
                      <span className="slider"></span>
                  </label>
              </div>
          )}

          <div className="options-container">
            <div className="option-item" role="button" onClick={() => setIsLocationModalOpen(true)}>
              <span>
                <i className="fa-solid fa-location-dot"></i> Alcance: 
                <span className="server-selection" id="currentserver">{displayLocation}</span>
              </span>
              <i className="fa-solid fa-chevron-right"></i>
            </div>

            <div className="option-item" role="button" onClick={() => setIsGroupModalOpen(true)}>
                <span>
                    <i className="fa-solid fa-users-rectangle"></i> Anexar Grupo
                </span>
                <i className="fa-solid fa-chevron-right"></i>
            </div>
          </div>
        </form>
      </main>

      {/* Location Modal */}
      {isLocationModalOpen && (
          <div className="location-modal-overlay" onClick={() => setIsLocationModalOpen(false)}>
              <div className="location-modal" onClick={(e) => e.stopPropagation()}>
                  <div className="modal-title">Definir Alcance do Reel</div>
                  
                  <div className="select-group">
                      <label>País</label>
                      <select value={targetCountry} onChange={handleCountryChange}>
                          <option value="">Todos / Global</option>
                          {countries.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                  </div>

                  {targetCountry && (
                      <div className="select-group">
                          <label>Estado</label>
                          <select value={targetState} onChange={handleStateChange}>
                              <option value="">Todos do País</option>
                              {states.map((s: string) => <option key={s} value={s}>{s}</option>)}
                          </select>
                      </div>
                  )}

                  {targetState && (
                      <div className="select-group">
                          <label>Cidade</label>
                          <select value={targetCity} onChange={(e) => setTargetCity(e.target.value)}>
                              <option value="">Todas do Estado</option>
                              {cities.map((c: string) => <option key={c} value={c}>{c}</option>)}
                          </select>
                      </div>
                  )}

                  <div className="modal-actions">
                      <button className="modal-btn clear-loc-btn" onClick={clearLocation}>Global</button>
                      <button className="modal-btn save-loc-btn" onClick={saveLocation}>Salvar</button>
                  </div>
              </div>
          </div>
      )}

      {/* Group Modal */}
      {isGroupModalOpen && (
          <div className="location-modal-overlay" onClick={() => setIsGroupModalOpen(false)}>
              <div className="location-modal" onClick={(e) => e.stopPropagation()}>
                  <div className="modal-title">Selecionar Grupo</div>
                  
                  <div className="group-list">
                      {myGroups.length > 0 ? myGroups.map(group => (
                          <div key={group.id} className="group-item" onClick={() => handleGroupSelect(group)}>
                              {group.coverImage ? (
                                  <img src={group.coverImage} className="group-cover" alt="Group" />
                              ) : (
                                  <div className="group-cover">
                                      <i className={`fa-solid ${group.isVip ? 'fa-crown' : 'fa-users'}`}></i>
                                  </div>
                              )}
                              <div className="group-info">
                                  <div className="group-name">{group.name}</div>
                                  <div className={`group-type ${group.isVip ? 'vip-tag' : ''}`}>
                                      {group.isVip ? 'VIP' : (group.isPrivate ? 'Privado' : 'Público')}
                                  </div>
                              </div>
                              <i className="fa-solid fa-chevron-right text-gray-500"></i>
                          </div>
                      )) : (
                          <div style={{textAlign:'center', color:'#777', padding:'20px'}}>
                              Nenhum grupo ativo disponível.
                          </div>
                      )}
                  </div>

                  <div className="modal-actions">
                      <button className="modal-btn clear-loc-btn" onClick={() => setIsGroupModalOpen(false)}>Fechar</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};