
import { Capacitor } from '@capacitor/core';

/**
 * Configuração Central da API
 * 
 * WEB: Se process.env.API_BASE_URL estiver vazio, usa '' (caminho relativo).
 * 
 * APK (NATIVE): 
 * Modificado para permitir funcionamento OFFLINE.
 * Se nenhuma URL for fornecida no build, o app assumirá que deve rodar em modo
 * standalone/offline (usando serviços locais simulados em database.ts).
 */

const getBaseUrl = () => {
    // @ts-ignore
    const envUrl = process.env.API_BASE_URL;
    
    // Verificação para ambiente nativo (APK)
    if (Capacitor.isNativePlatform() && !envUrl) {
        console.warn("⚠️ [APK] 'VITE_API_BASE_URL' não definida. O app rodará em MODO OFFLINE (Standalone).");
        return ''; // Retorna string vazia para evitar erros de construção de URL
    }

    if (envUrl) {
        // Remove a barra final se existir para padronizar
        const url = envUrl.endsWith('/') ? envUrl.slice(0, -1) : envUrl;
        console.log(`🔌 [API] Conectado a: ${url}`);
        return url;
    }
    
    return '';
};

export const API_BASE = getBaseUrl();
